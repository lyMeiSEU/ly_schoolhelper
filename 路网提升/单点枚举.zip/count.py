num1 = []
num2 = []
for i in range(0, 14):
    for j in range(0, 14 - i):
        k = 0
        while k <= 13 - i - j:
            k+=1
            a = [i,j,k]
            #print(a)
            num1.append(a)
print(len(num1))

for i in range(0, 25):

    k = 0

    while k < 15:
        k += 1
        b = [i, k]
        num2.append(a)
print(len(num2))


num3 = []
num4 = []
for i in range(0, 8):
    for j in range(0, 8 - i):
        k = 0
        while k <= 8 - i - j:
            k+=1
            c = [i,j,k]
            #print(a)
            num3.append(c)
print(len(num3))

for i in range(0, 10):

    k = 0

    while k < 10:
        k += 1
        d = [i, k]
        num4.append(d)
print(len(num4))

z = 560*20 + 375*20
y = z/3600
print(y, z)
print()
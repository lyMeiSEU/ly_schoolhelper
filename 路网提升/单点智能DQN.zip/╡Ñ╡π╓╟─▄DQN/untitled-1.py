import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
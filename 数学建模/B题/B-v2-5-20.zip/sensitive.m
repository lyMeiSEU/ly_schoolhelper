xm = mean(xn,2);
for i = 1:1:10
    xl = xm*ones(1,11);
    xl(i, :) = xl(i, :) .* [0.95:0.01:1.05];
    plot(0.95:0.01:1.05, sim(net, xl));
    if i == 1
        hold;
    end
end
title('������ģ�������ȷ���');
xlabel('{\Delta}x');
ylabel('{\Delta}y');
legend('x_1','x_2','x_3','x_4','x_5','x_6','x_7','x_8','x_9','x_{10}');
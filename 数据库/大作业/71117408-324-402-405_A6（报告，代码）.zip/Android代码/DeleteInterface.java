package com.example.test;
/**
 * 删除接口
 * 创建人：杜昕昱
 * 创建时间：2019.8.26
 * 功能：实现确定和取消并传入参数。
 */
import android.view.View;

public interface DeleteInterface {
    public void buttonYesClicked(View v);
    public void buttonNoClicked();
}

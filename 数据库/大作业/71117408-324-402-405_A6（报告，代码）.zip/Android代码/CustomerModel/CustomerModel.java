package com.example.test.CustomerModel;
/**
 * Author 71117415-喻泽弘
 * Date 2019.9.10
 * 静态类判断是否为游客模式使用app
 * */
public class CustomerModel {
    static public boolean isCustomer=false;
}

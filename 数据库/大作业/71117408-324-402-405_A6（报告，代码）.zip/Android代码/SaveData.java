package com.example.test;

import android.content.SharedPreferences;
import android.content.Context;

public class SaveData {

    public static final String FILE_NAME = "my_sp";
    public Context context;
   // PreferenceManager preferences ;

//    public SaveData(){
//        //preferences = getSharedPreferences("login",MODE_PRIVATE);
//        context = null;
//    }
//
//    /*
//    写入到文件中，输出流
//     */
//    public void saveToFile(String filename,String filecontent)throws Exception{
//        //       //私有模式，创建出来的文件只能本应用访问，会覆盖原来文件
//        FileOutputStream output = context.openFileOutput(filename,Context.MODE_PRIVATE);
//        output.write(filecontent.getBytes());
//        output.close();
//
//    }
//
//    /*
//    从文件中读取，输入流
//     */
//    public String readFromFile(String filename)throws IOException{
//        //打开文件s输入流
//        FileInputStream inputStream = context.openFileInput(filename);
//        byte[] temp = new byte[1024];
//        StringBuilder sb = new StringBuilder("");
//        int len = 0;
//        //读取文件内容
//        while((len=inputStream.read(temp))>0){
//            sb.append(new String(temp,0,len));
//        }
//        //关闭输入流
//        inputStream.close();
//        return sb.toString();
//    }

    //偏好设置-获取主数据库的函数
    public static SharedPreferences share(Context context){
        SharedPreferences sharedPreferences = context.getSharedPreferences("data",Context.MODE_PRIVATE);
        return sharedPreferences;
    }

    //========================================================set部分开始==================================================================
    /*
    保存偏好设置
     */
    /*
    setAll 总设置，调用所以set方面的函数进行赋值
    setName() 设置姓名
    getName() 获取姓名
     */
    public static boolean setNumber(Integer number,Context context){
        SharedPreferences.Editor e = share(context).edit();
        e.putInt("number",number);
        Boolean b = e.commit();
        return b;
    }
    public static  void setName(String name,Context context){
        SharedPreferences.Editor e = share(context).edit();
        e.putString("name",name);
        e.apply();
    }
    public static  void setPasswd(String passwd,Context context){
        SharedPreferences.Editor e = share(context).edit();
        e.putString("passwd",passwd);
        e.apply();
    }
    public static void setAccount(String account,Context context){
        SharedPreferences.Editor e = share(context).edit();
        e.putString("account",account);
        e.apply();
    }
    public static void setAim(String aim,Context context){
        SharedPreferences.Editor e = share(context).edit();
        e.putString("aim",aim);
        e.apply();
    }

    public static boolean setAll(Integer number,String name, String passwd,String account , String aim ,Context context){
        boolean b = setNumber(number,context);
        setName(name,context);
        setPasswd(passwd,context);
        setAccount(account,context);
        setAim(aim,context);
        if(b){
            System.out.println("保存成功！");
            return true;
        }
        else {
            System.out.println("保存失败！");
            return  false;
        }

    }
    //========================================================set部分结束==================================================================
    //========================================================get部分开始==================================================================
    public static Integer getNumber(Context context){
        return share(context).getInt("number",-1);
    }
    public static String getName(Context context){
        return share(context).getString("name",null);
    }
    public static String getPasswd(Context context){
        return share(context).getString("passwd",null);
    }
    public static String getAccount(Context context){
        return share(context).getString("account",null);
    }
    public static String getAim(Context context){
        return share(context).getString("aim",null);
    }
    //========================================================get部分结束==================================================================

}



























//    public void savePreferences(String username,String passwd){
//        SharedPreferences sp = context.getSharedPreferences("my_sp",Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = sp.edit();
//        editor.putString("username",username);
//        editor.putString("passwd",passwd);
//        editor.commit();
//        Toast.makeText(context,"信息已经写入SharedPreference中",Toast.LENGTH_SHORT).show();
//    }
//
//    /*
//    读取偏好设置
//     */
//    public Map<String,String> read(){
//        Map<String,String> data = new HashMap<String,String>();
//        SharedPreferences sp = context.getSharedPreferences("my_sp",Context.MODE_PRIVATE);
//        data.put("username",sp.getString("username",""));
//        data.put("passwd",sp.getString("passwd",""));
//        return data;
//
//    }
//
//    /*
//    保存偏好数据
//     */
//    public static void put(Context context,String key,Object obj){
//        SharedPreferences sp = context.getSharedPreferences(FILE_NAME,context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = sp.edit();
//        if (obj instanceof Boolean) {
//            editor.putBoolean(key, (Boolean) obj);
//        } else if (obj instanceof Float) {
//            editor.putFloat(key, (Float) obj);
//        } else if (obj instanceof Integer) {
//            editor.putInt(key, (Integer) obj);
//        } else if (obj instanceof Long) {
//            editor.putLong(key, (Long) obj);
//        } else {
//            editor.putString(key, (String) obj);
//        }
//        editor.commit();
//    }
//    /*
//    获取偏好数据
//     */
//    public static Object get(Context context,String key,Object defaultObj ){
//        SharedPreferences sp = context.getSharedPreferences(FILE_NAME, context.MODE_PRIVATE);
//        if (defaultObj instanceof Boolean) {
//            return sp.getBoolean(key, (Boolean) defaultObj);
//        } else if (defaultObj instanceof Float) {
//            return sp.getFloat(key, (Float) defaultObj);
//        } else if (defaultObj instanceof Integer) {
//            return sp.getInt(key, (Integer) defaultObj);
//        } else if (defaultObj instanceof Long) {
//            return sp.getLong(key, (Long) defaultObj);
//        } else if (defaultObj instanceof String) {
//            return sp.getString(key, (String) defaultObj);
//        }
//        return null;
//    }
//
//    /**
//     * 删除指定数据
//     */
//    public static void remove(Context context, String key) {
//        SharedPreferences sp = context.getSharedPreferences(FILE_NAME, context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = sp.edit();
//        editor.remove(key);
//        editor.commit();
//    }
//
//
//    /**
//     * 返回所有键值对
//     */
//    public static Map<String, ?> getAll(Context context) {
//        SharedPreferences sp = context.getSharedPreferences(FILE_NAME, context.MODE_PRIVATE);
//        Map<String, ?> map = sp.getAll();
//        return map;
//    }
//
//    /**
//     * 删除所有数据
//     */
//    public static void clear(Context context) {
//        SharedPreferences sp = context.getSharedPreferences(FILE_NAME, context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = sp.edit();
//        editor.clear();
//        editor.commit();
//    }
//
//    /**
//     * 检查key对应的数据是否存在
//     */
//    public static boolean contains(Context context, String key) {
//        SharedPreferences sp = context.getSharedPreferences(FILE_NAME, context.MODE_PRIVATE);
//        return sp.contains(key);
//    }
//

//    /**设置缓存
//     content是要存储的内容，可以是任意格式的，不一定是字符串。
//     */
//    public static void setCache(String content,Context context, String cacheFileName,int mode) {
//        FileOutputStream fos = null;
//        try {
//            //打开文件输出流，接收参数是文件名和模式
//            fos = context.openFileOutput(cacheFileName,mode);
//            fos.write(content.getBytes());
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            if(fos != null) {
//                try {
//                    fos.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//    }
//
//    //读取缓存，返回字符串（JSON）
//    public static String getCache(Context context, String cacheFileName) {
//        FileInputStream fis = null;
//        StringBuffer sBuf = new StringBuffer();
//        try {
//            fis = context.openFileInput(cacheFileName);
//            int len = 0;
//            byte[] buf = new byte[1024];
//            while ((len = fis.read(buf)) != -1) {
//                sBuf.append(new String(buf,0,len));
//            }
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }finally {
//            if(fis != null) {
//                try {
//                    fis.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//        if(sBuf != null) {
//            return sBuf.toString();
//        }
//        return null;
//    }
//
//    public static String getCachePath(Context context) {
//        return context.getFilesDir().getAbsolutePath();
//    }




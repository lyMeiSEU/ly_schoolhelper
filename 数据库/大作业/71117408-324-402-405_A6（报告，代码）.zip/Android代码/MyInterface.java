package com.example.test;

public interface MyInterface {//absorbActivity实现本接口以定义finish弹窗yes或no操作
    public void buttonYesClicked();
    public void buttonNoClicked();

}

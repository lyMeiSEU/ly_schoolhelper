package com.example.test;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteHelper extends SQLiteOpenHelper {

    private final static String DATABASE_NAME = "dataBase";
    private final static int DATABASE_VERSION = 1;
    private final static String TABLE_NAME_RECORD = "Record";
    private Context mContext;
    int c = 0;
    //构造函数，创建数据库
    public SQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        mContext = context;
    }


    //建表
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE_NAME_RECORD
                + "(Counter INTEGER PRIMARY KEY AUTOINCREMENT,"
                + " Job_name VARCHAR(30)  NOT NULL,"
                + " Job_type VARCHAR(30),"
                + " Job_scene VARCHAR(30),"
                + " Create_time VARCHAR(30),"
                + " Start_time VARCHAR(30),"
                + " End_time VARCHAR(30),"
                + " Suspend_duration INTEGER,"
                + " Set_duration INTEGER,"
                + " Actual_duration INTEGER,"
                + " Concentration INTEGER,"
                + " Circularity INTEGER,"
                + " Ignition DOUBLE,"
                + " Silence DOUBLE,"
                + " To_ignition DOUBLE,"
                + " Daliy INTEGER,"
                + " Total INTEGER)";
        System.out.println("-----------------------> sql has been created");
        db.execSQL(sql);
    }


    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE IF EXISTS " + TABLE_NAME_RECORD;
        db.execSQL(sql);
        onCreate(db);
    }

    //获取游标
    public Cursor select() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME_RECORD, null, null, null, null, null, null);
        return cursor;
    }

    //插入一条记录
//    public long insert(String bookName,String author,String publisher ) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues cv = new ContentValues();
//        cv.put("BookName", bookName);
//        cv.put("Author", author);
//        cv.put("Publisher", publisher);
//        long row = db.insert(TABLE_NAME_RECORD, null, cv);
//        return row;
//    }

    //暂不用
    //根据条件查询
    public void queryAll(String[] args) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("Record",null,null,null,null,null,null);
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++Query++++++++++++++++++++++++++++++++++++++++++++++++++++");
        if(cursor.moveToFirst()){
            do{
                System.out.println("--------------------------------Query--------------------------------");
                System.out.println(cursor.getString(cursor.getColumnIndex("Counter")));
                System.out.println(cursor.getString(cursor.getColumnIndex("Ignition")));
                System.out.println(cursor.getString(cursor.getColumnIndex("To_ignition")));
                System.out.println(cursor.getString(cursor.getColumnIndex("Silence")));
                System.out.println("--------------------------------Query--------------------------------");

            }while(cursor.moveToNext());
        }
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++Query++++++++++++++++++++++++++++++++++++++++++++++++++++");
       return;
    }

    //删除记录
    public void delete(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String where ="_id = ?";
        String[] whereValue = { Integer.toString(id) };
        db.delete(TABLE_NAME_RECORD, where, whereValue);
    }

    //更新记录
    public void update(int id,int counter,String job_name,String job_type,String job_scene,
                       String create_time,String start_time, String end_time,
                       int suspend_duration, int set_duration,int actual_duration,
                       int concentration,int circularity,
                       double ignition,double silence,double to_ignition,
                       int daliy,int total) {
        SQLiteDatabase db = this.getWritableDatabase();
        String where = "_id = ?";
        String[] whereValue = { Integer.toString(id) };
        ContentValues cv = new ContentValues();
        cv.put("Counter", counter);
        cv.put("Job_name", job_name);
        cv.put("Job_type", job_type);
        cv.put("Job_scene", job_scene);
        cv.put("Create_time", create_time);
        cv.put("Start_time", start_time);
        cv.put("End_time", end_time);
        cv.put("Suspend_duration", suspend_duration);
        cv.put("Set_duration", set_duration);
        cv.put("Actual_duration", actual_duration);
        cv.put("Concentration", concentration);
        cv.put("Circularity", circularity);
        cv.put("Ignition", ignition);
        cv.put("Silence", silence);
        cv.put("To_ignition", to_ignition);
        cv.put("Daliy", daliy);
        cv.put("Total", total);
        System.out.println("-----------------------> one record has been inserted");
        db.update(TABLE_NAME_RECORD, cv, where, whereValue);
    }

    //存入一条完整记录
    public long insertRecord(int counter,String job_name,String job_type,String job_scene,
                             String create_time,String start_time, String end_time,
                             int suspend_duration, int set_duration,int actual_duration,
                             int concentration,int circularity,
                             double ignition,double silence,double to_ignition,
                             int daliy,int total) {
        System.out.println("-----------------------> try to insert one record 2");
        SQLiteDatabase db = this.getWritableDatabase();
        System.out.println("-----------------------> try to insert one record 1");
        ContentValues cv = new ContentValues();
        System.out.println("-----------------------> try to insert one record 0");
        cv.put("Counter", counter);System.out.println("-----------------------> try to insert "+counter);
        cv.put("Job_name", job_name);System.out.println("-----------------------> try to insert "+job_name);
        cv.put("Job_type", job_type);System.out.println("-----------------------> try to insert "+job_type);
        cv.put("Job_scene", job_scene);System.out.println("-----------------------> try to insert "+job_scene);
        cv.put("Create_time", create_time);System.out.println("-----------------------> try to insert "+create_time);
        cv.put("Start_time", start_time);System.out.println("-----------------------> try to insert "+start_time);
        cv.put("End_time", end_time);System.out.println("-----------------------> try to insert "+end_time);
        cv.put("Suspend_duration", suspend_duration);System.out.println("-----------------------> try to insert "+suspend_duration);
        cv.put("Set_duration", set_duration);System.out.println("-----------------------> try to insert "+set_duration);
        cv.put("Actual_duration", actual_duration);System.out.println("-----------------------> try to insert "+actual_duration);
        cv.put("Concentration", concentration);System.out.println("-----------------------> try to insert "+concentration);
        cv.put("Circularity", circularity);System.out.println("-----------------------> try to insert "+circularity);
        cv.put("Ignition", ignition);System.out.println("-----------------------> try to insert "+ignition);
        cv.put("Silence", silence);System.out.println("-----------------------> try to insert "+silence);
        cv.put("To_ignition", to_ignition);System.out.println("-----------------------> try to insert "+to_ignition);
        cv.put("Daliy", daliy);System.out.println("-----------------------> try to insert "+daliy);
        cv.put("Total", total);System.out.println("-----------------------> try to insert "+total);

        long row = db.insert(TABLE_NAME_RECORD, null, cv);
        cv.clear();
        return row;
    }


}


//private SQLiteHelper helper;
//helper.insert(editBook.getText().toString(), editAuthor.getText().toString(), editPublisher.getText().toString());
// helper.update(id, editBook.getText().toString(), editAuthor.getText().toString(), editPublisher.getText().toString());
package com.example.test;


import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.test.Client.ServerClient;
import com.example.test.login.LoginActivity;
import com.vite.audiolibrary.FmlPlayer;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class AbsorbActivity extends AppCompatActivity implements View.OnClickListener{

    private ImageButton playVideoBtn, stopTimeBtn, finishTimeBtn;
    private TextView displayStopTime;
    private TextView displayAbsorbTime;
    private TextView diaplayFeedbackTime;
    private TextView planName;

    //初始化总暂停时间和总专注时间
    private int studyTimeSum = 0;
    private int stopTimeSum = 0;


    private boolean isContinue = false;


    private int absorbTime = 0;
    private int finalAbsorbTime = 0;
    private int stopTime = 180;
    private final int finalStopTime = 180;
    private int restTime = 180;

    //任务属性
    private String username;
    private MissionInfo mission;
    private String studyName;
    private String jobStartTime,jobEndTime;

    //倒计时用的timer与task
    private Timer timer = null;
    private TimerTask timerTask = null;

    //暂停，结束与反馈三个dialog
    private AlertDialog stopDialog = null;
    private AlertDialog finishDialog = null;
    private AlertDialog feedbackDialog = null;

    //进度条
    private float mTotalProgress = 100;
    private float mCurrentProgress = 0;
    private CompletedView mTasksView;
    private Thread CirViewThread = null;
    public boolean isStop = false;//用来判断是否暂停

    //反馈值
    private int concentration = 0;
    private int circularity = 0;
    private FmlPlayer mPlayer;
    private Handler handler1=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        jobStartTime = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS")).format(Calendar.getInstance().getTime());
        //利用intent得到本次学习时间和学习名称

        //从之前activity得到本次任务的名称与规定时间
        Intent intent = getIntent();
        username=intent.getStringExtra("username");
        mission=(MissionInfo) intent.getSerializableExtra("mission");
        absorbTime =mission.jobDuration*60;
        studyName=mission.jobName;
        finalAbsorbTime = absorbTime;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_absorb);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        Message message = mHandlerMain.obtainMessage();
        String timeText = TimerUtils.getTime(absorbTime);
        message.obj = timeText;
        mHandlerMain.sendMessage(message);//开始专注倒计时

        initView();
        FmlPlayer.init(this, true);

        mPlayer = new FmlPlayer();

        mPlayer.setAssetFile("noise.mp3");
        mPlayer.prepare();



    }


    /**
     * @author 杨宇
     * @function 绘制圆形进度条
     * @date 2019.9.10
     * @param
     * @return
     */
    class ProgressRunable implements Runnable {

        int TotalStudyTime;

        ProgressRunable(int time) {
            TotalStudyTime = time;
        }


        /**
         * 每0.1秒更新一次圆形进度条的进度
         * 当时间暂停时，利用isSTOP这个boolean变量来判断是否继续画，同时取消暂停时更新此时进度
         * @param
         * @return
         */
        @Override
        public void run() {
            while (mCurrentProgress < mTotalProgress) {

                if (isStop) {
                    continue;
                }
                mCurrentProgress += 0.01 * (1000 / (float) TotalStudyTime);//每隔0.1s更新一次进度
                mTasksView.setProgress(mCurrentProgress);
                try {
                    Thread.sleep(100);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @author 杨宇
     * @function 连接布局
     * @date 2019.9.10
     * @param
     * @return
     */
    private void initView() {
        playVideoBtn = findViewById(R.id.playvideo);
        stopTimeBtn = findViewById(R.id.stoptime);
        finishTimeBtn = findViewById(R.id.finishtime);
        displayAbsorbTime = findViewById(R.id.displayabsorbtime);
        planName = findViewById(R.id.planname);
        playVideoBtn.setOnClickListener(this);
        stopTimeBtn.setOnClickListener(this);
        finishTimeBtn.setOnClickListener(this);
        planName.setText(studyName);


        mTasksView = (CompletedView) findViewById(R.id.tasks_view);

        CirViewThread = new Thread(new ProgressRunable(finalAbsorbTime));

        CirViewThread.start();//绘制进度条开始
    }

    /**
     * @author 杨宇
     * @function 专注界面三个按钮设置监听
     * 分别为播放白噪音、暂停、退出三个按钮
     * @date 2019.9.10
     * @param
     * @return
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.finishtime:
                isStop = true;
                stopTimeMain();
                showDialogFinish();
                break;
            case R.id.playvideo:
                if(!mPlayer.isPlaying())
                    mPlayer.play();
                else mPlayer.pause();
                break;
            case R.id.stoptime:

                //由于本系统对某次任务规定暂停时间，当暂停时间结束时将不允许暂停
                if(stopTime == 0)
                {
                    Toast.makeText(AbsorbActivity.this, "暂停时间结束，请继续学习", Toast.LENGTH_SHORT).show();
                }else {
                    isStop = true;
                    stopTimeMain();
                    showDialogStop();//展示暂停dialog
                }
                break;
            default:
                break;
        }

    }

    //打印专注倒计时
    private Handler mHandlerMain = new Handler() {
        public void handleMessage(Message msg) {
            displayAbsorbTime.setText(msg.obj.toString() + "");
            startTimeMain();
        }

        ;
    };
    //打印暂停倒计时
    private Handler mHandlerStop = new Handler() {
        public void handleMessage(Message msg) {
            displayStopTime.setText(msg.obj.toString() + "");
            startTimeStop();
        }

        ;
    };
    //打印反馈倒计时
    private Handler mHandlerRest = new Handler() {
        public void handleMessage(Message msg) {
            diaplayFeedbackTime.setText(msg.obj.toString() + "");
            startTimeRest();
        }

        ;
    };

    /**
     * @author 杨宇
     * @function 专注倒计时更新
     * @date 2019.9.10
     * @param
     * @return
     */
    public void startTimeMain() {

        timer = new Timer();
        timerTask = new TimerTask() {

            @Override
            public void run() {
                if (absorbTime > 0) {   //加入判断不能小于0
                    absorbTime--;
                    传递信息
                    Message message = mHandlerMain.obtainMessage();
                    String timeText = TimerUtils.getTime(absorbTime);
                    message.obj = timeText;
                    mHandlerMain.sendMessage(message);
                }
            }
        };
        timer.schedule(timerTask, 1000);

        //专注时间结束
        if (absorbTime == 0) {
            stopTimeMain();
            showDialogFeedback();
        }
    }

    /**
     * @author 杨宇
     * @function 暂停倒计时更新
     * @date 2019.9.10
     * @param
     * @return
     */
    public void startTimeStop() {


        timer = new Timer();
        timerTask = new TimerTask() {

            @Override
            public void run() {
                if (stopTime > 0) {   //加入判断不能小于0
                    stopTime--;
                    Message message = mHandlerStop.obtainMessage();
                    String timeText = TimerUtils.getTime(stopTime);
                    message.obj = timeText;
                    mHandlerStop.sendMessage(message);
                }

            }
        };
        timer.schedule(timerTask, 1000);

        //暂停时间结束，强制继续学习
        if (stopTime == 0) {
            Toast.makeText(AbsorbActivity.this, "暂停时间结束，请继续学习", Toast.LENGTH_SHORT).show();
            mCurrentProgress = ((float)(finalAbsorbTime - absorbTime))/ finalAbsorbTime *100;
            mTasksView.setProgress(mCurrentProgress);
            isStop = false;

            stopTimeStop();
            stopDialog.dismiss();

            stopDialog = null;

            Message message = mHandlerMain.obtainMessage();
            String timeText = TimerUtils.getTime(absorbTime);
            message.obj = timeText;
            mHandlerMain.sendMessage(message);
        }
    }

    /**
     * @author 杨宇
     * @function 反馈倒计时更新
     * @date 2019.9.10
     * @param
     * @return
     */
    public void startTimeRest() {

        timer = new Timer();
        timerTask = new TimerTask() {

            @Override
            public void run() {
                if (restTime > 0) {   //加入判断不能小于0
                    restTime--;
                    Message message = mHandlerRest.obtainMessage();
                    String timeText = TimerUtils.getTime(restTime);
                    message.obj = timeText;
                    mHandlerRest.sendMessage(message);
                }
            }
        };
        timer.schedule(timerTask, 1000);

        //反馈时间结束未反馈
        if(restTime == 0)
        {
            updateToServer();
            stopTimeRest();
            mPlayer.stop();
            mPlayer.release();
            feedbackDialog.dismiss();
            finish();
        }
    }


    //专注界面暂停
    public void stopTimeMain() {

        timer.cancel();
        timer = null;
        timerTask = null;
    }

    //暂停界面暂停
    public void stopTimeStop() {
        timer.cancel();
        timer = null;
        timerTask = null;
    }

    //暂停界面暂停
    public void stopTimeRest() {
        timer.cancel();
        timer = null;
        timerTask = null;
    }

    /**
     * @author 杨宇
     * @function 结束dialog实现
     * 分别有取消与继续学习按钮，本函数下实现监听
     * @date 2019.9.10
     * @param
     * @return
     */
    public void showDialogFinish() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);


        final View v = getLayoutInflater().inflate(R.layout.mdiaologfinish, null);
        builder.setView(v);
        builder.setCancelable(false);
        Button cancel = v.findViewById(R.id.cancelBtn);
        Button yes = v.findViewById(R.id.yesBtn);


        //取消结束监听
        cancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                //更新圆形进度条
                mCurrentProgress = ((float)(finalAbsorbTime - absorbTime))/ finalAbsorbTime *100;
                mTasksView.setProgress(mCurrentProgress);
                isStop = false;

                //开始专注计时
                Message message = mHandlerMain.obtainMessage();
                String timeText = TimerUtils.getTime(absorbTime);
                message.obj = timeText;
                mHandlerMain.sendMessage(message);

                Toast.makeText(AbsorbActivity.this, "学习继续", Toast.LENGTH_SHORT).show();
                finishDialog.dismiss();
            }
        });

        //继续学习监听
        yes.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                stopTimeSum = finalStopTime - stopTime;
                studyTimeSum = finalAbsorbTime - absorbTime;

                Toast.makeText(AbsorbActivity.this, "退出本次学习", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent();
                intent.putExtra("studyTime_return", studyTimeSum);
                intent.putExtra("stopTime_return", stopTimeSum);
                setResult(RESULT_OK, intent);

                mPlayer.stop();
                mPlayer.release();

                finish();
            }
        });


        finishDialog = builder.show();

    }



    /**
     * @author 杨宇
     * @function 暂停dialog实现
     * 包含继续学习即取消暂停的监听
     * @date 2019.9.10
     * @param
     * @return
     */
    public void showDialogStop() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        final View v = getLayoutInflater().inflate(R.layout.dialog_layout, null);
        displayStopTime = v.findViewById(R.id.displaystoptime);
        builder.setView(v);
        builder.setCancelable(false);

        Message message = mHandlerStop.obtainMessage();
        String timeText = TimerUtils.getTime(stopTime);
        message.obj = timeText;
        mHandlerStop.sendMessage(message);


        Button continueStudy = v.findViewById(R.id.continueBtn);

        continueStudy.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                //更新圆形进度条
                mCurrentProgress = ((float)(finalAbsorbTime - absorbTime))/ finalAbsorbTime *100;
                mTasksView.setProgress(mCurrentProgress);
                isStop = false;
                stopTimeStop();

                //继续专注计时
                Message message = mHandlerMain.obtainMessage();
                String timeText = TimerUtils.getTime(absorbTime);
                message.obj = timeText;
                mHandlerMain.sendMessage(message);
                Toast.makeText(AbsorbActivity.this, "学习继续", Toast.LENGTH_SHORT).show();
                stopDialog.dismiss();
            }
        });

        stopDialog = builder.show();

    }


    /**
     * @author 杨宇
     * @function 结束dialog实现
     * @date 2019.9.10
     * @param
     * @return
     */
    public void showDialogFeedback() {


        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        Toast.makeText(AbsorbActivity.this, "请反馈本次学习情况", Toast.LENGTH_SHORT).show();
        final View v = getLayoutInflater().inflate(R.layout.dialogfeedback, null);
        builder.setView(v);
        builder.setCancelable(false);
        jobEndTime=(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS")).format(Calendar.getInstance().getTime());
        final Button btn_Submit = v.findViewById(R.id.SubmitBtn);
        final SeekBar ccttBar = v.findViewById(R.id.ConcentrationBar);
        final SeekBar cclrtBar = v.findViewById(R.id.CircularityBar);
        final TextView textConcentration = v.findViewById(R.id.concentrationVar);
        final TextView textCircularity = v.findViewById(R.id.circularityVar);


        diaplayFeedbackTime = v.findViewById(R.id.displayfeedbacktime);

        //stopTimeMain();
        Message message = mHandlerRest.obtainMessage();
        String timeText = TimerUtils.getTime(restTime);
        message.obj = timeText;
        mHandlerRest.sendMessage(message);


        //设置监听当seekbar变动时下方textview得到seekbar此时数值
        ccttBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onStopTrackingTouch(SeekBar seekbar)
            {
                return ;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekbar)
            {
                return ;
            }

            @Override
            public void onProgressChanged(SeekBar seekBar,int progress, boolean fromUser)
            {
                int var =seekBar.getProgress();
                textConcentration.setText(Integer.toString(var));//下方textviewx显示数值
            }
        });
        //设置监听当seekbar变动时下方textview得到seekbar此时数值
        cclrtBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onStopTrackingTouch(SeekBar seekbar)
            {
                return ;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekbar)
            {
                return ;
            }

            @Override
            public void onProgressChanged(SeekBar seekBar,int progress, boolean fromUser)
            {
                int var =seekBar.getProgress();
                textCircularity.setText(Integer.toString(var));//下方textviewx显示数值
            }
        });

        feedbackDialog = builder.show();

        stopTimeSum = finalStopTime - stopTime;
        studyTimeSum = finalAbsorbTime - absorbTime;
        concentration = ccttBar.getProgress();
        circularity = cclrtBar.getProgress();


        //提交反馈按钮监听
        btn_Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                concentration = ccttBar.getProgress();
                circularity = cclrtBar.getProgress();

                updateToServer();
                stopTimeRest();

                //音频播放移出
                mPlayer.stop();
                mPlayer.release();

                feedbackDialog.dismiss();


                finish();
            }
        });
    }

    /**
     * @author 杨宇
     * @function 向服务器返回信息
     * @date 2019.9.10
     * @param
     * @return
     */
    private void updateToServer()
    {
        JSONObject object=new JSONObject();
        try {
            object.put("method","userJobFinish");
            object.put("userAccount",username);
            object.put("currentTime",calendarToString(Calendar.getInstance()));
            jsonAddMission(object,mission);
            object.put("jobSusbendTime",stopTimeSum);
            object.put("concentration",concentration);
            object.put("circularity",circularity);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ServerClient serverClient=null;
        try {
            serverClient=new ServerClient(object.toString(),"POST",handler1);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        new Thread(serverClient).start();
        Toast.makeText(AbsorbActivity.this, "退出本次学习", Toast.LENGTH_SHORT).show();
        try {
            LoginActivity.mdt.getIa().JobEnd(Calendar.getInstance(),stopTimeSum,circularity,concentration); //----------------------------------------------
            Intent intent = new Intent();
            intent.putExtra("silence",LoginActivity.mdt.getIa().GetCurrentSilence());
            System.out.println("---------->"+ LoginActivity.mdt.getIa().GetCurrentSilence());
            intent.putExtra("burning", LoginActivity.mdt.getIa().GetToIgnition());
            System.out.println("---------->"+ LoginActivity.mdt.getIa().GetToIgnition());
            //           intent.putExtra("")
            setResult(RESULT_OK, intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //json加入任务
    private void jsonAddMission(JSONObject object,MissionInfo m){
        try {
            object.put("jobName",m.jobName);
            object.put("jobSetDuration",m.jobDuration);
            object.put("jobAlreadyTime",m.jobAlreadyTime);
            object.put("jobCreateTime",calendarToString(m.jobCreateTime));
            object.put("jobStartTime",jobStartTime);
            object.put("jobEndTime",jobEndTime);
            object.put("jobType",m.jobType);
            object.put("jobScene",m.jobScene);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    //Calendar 转String
    public String calendarToString(Calendar c){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dateStr = sdf.format(c.getTime());
        return dateStr;
    }
    private Handler handler=new Handler()
    {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            //Answer.answer=msg.obj.toString();
            System.out.println("Get From subThread"+msg.toString());
        }
    };

}




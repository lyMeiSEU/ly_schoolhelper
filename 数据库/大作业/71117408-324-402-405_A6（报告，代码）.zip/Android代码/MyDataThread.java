package com.example.test;

import android.content.Context;

public class MyDataThread{

    private Context context;
    private SQLiteHelper sql;
    private SaveData sd;
    private IgnitionAlgorithm ia;

    public MyDataThread(Context ctext){
        context = ctext;
        sql = new SQLiteHelper(context);
        sd = new SaveData();
        ia = new IgnitionAlgorithm(sql);
    }

    public MyDataThread(Context ctext,double slience,double ignition){
        context = ctext;
        sql = new SQLiteHelper(context);
        sd = new SaveData();
        ia = new IgnitionAlgorithm(sql,slience,ignition);
    }

    public SQLiteHelper getSql(){
        return  sql;
    }
    public SaveData getSd(){
        return sd;
    }
    public IgnitionAlgorithm getIa(){
        return ia;
    }


}

package com.example.test.data.model;
/**
 * 静态类
 * Author 71117415-喻泽弘
 * function 获取登录返回的结果
 * Date 2019.8.29
 * */
public class Answer {
    static public String answer="";
    public void setAnswer(String answer)
    {
        this.answer=answer;
    }
    public void clear()
    {
        answer="";
    }
}

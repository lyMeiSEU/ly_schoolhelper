package com.example.test.data;

/**
 * function 登录结果类 返回登录的3种结果 成功，失败，错误
 * Author 71117415-喻泽弘
 * Date 2019.8.21
 */
public class Result<T> {
    // hide the private constructor to limit subclass types (Success, Error)
    private Result() {
    }

    @Override
    public String toString() {
        if (this instanceof Result.Success) {
            Result.Success success = (Result.Success) this;
            return "Success[data=" + success.getData().toString() + "]";
        } else if (this instanceof Result.Error) {
            Result.Error error = (Result.Error) this;
            return "Error[exception=" + error.getError().toString() + "]";
        }
        return "";
    }

    // Success sub-class
    // 成功的子类
    public final static class Success<T> extends Result {
        private T data;

        public Success(T data) {
            this.data = data;
        }

        public T getData() {
            return this.data;
        }
    }

    // Error sub-class
    // 失败的子类
    public final static class Error extends Result {
        private Exception error;

        public Error(Exception error) {
            this.error = error;
        }

        public Exception getError() {
            return this.error;
        }
    }
    // Wrong sub-class
    //错误的子类
    public final static class Wrong<T> extends Result
    {
        private T data;
        public Wrong(T data) {
            this.data = data;
        }

        public T getData() {
            return this.data;
        }
    }
}

package com.example.test;
/**
 * 删除任务对话框类
 * 创建人：杜昕昱
 * 创建时间：2019.8.28
 * 功能：在任务删除时显示对话框并在界面删除任务。
 */
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

public class DeleteDialog extends DialogFragment {
    private View view;
    public DeleteDialog(View v){
        view=v;
    }
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("是否删除");
        builder.setMessage("是否确定删除该任务?");
        builder.setCancelable(false);
        builder.setPositiveButton("是", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DeleteInterface myInterface = (DeleteInterface) getFragmentManager().findFragmentByTag("android:switcher:"+R.id.vpager+":0");
                myInterface.buttonYesClicked(view);
            }
        });
        builder.setNegativeButton("否", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //DeleteInterface myInterface = (DeleteInterface)getActivity();
                //myInterface.buttonNoClicked();
                Toast.makeText(getActivity(), "取消删除", Toast.LENGTH_SHORT).show();
            }
        });


        return builder.create();
    }
}

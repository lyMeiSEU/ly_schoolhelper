/**
 *专注页面fragment
 * 创建时间：2019.8.24
 * 创建人：杜昕昱
 * 功能：此功能为实现任务主界面，用户可以看到自己的待完成任务，进行任务添加，任务删除，进入任务专注等功能。fragment在switchactivity中的viewpage进行切换
 */
package com.example.test;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.test.Client.ServerClient;
import com.example.test.CustomerModel.CustomerModel;
import com.example.test.login.LoginActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedList;

import static android.app.Activity.RESULT_OK;


public class ConcentrateFragment extends Fragment implements DeleteInterface {
    private String username;//用户名，用于向数据库发送请求
    private ImageButton addMission;
    private Context mContext;
    private LinearLayout mBackground;
    private int missionNum, concentrateTime;//任务个数,距离上次专注时间。
    private double burningDegree, silenceDegree;//燃度值，默度值
    private LinkedList<RelativeLayout> missionList;//任务控件链表
    private LinkedList<ImageButton> missionStartList;//任务开始键链表
    private LinkedList<MissionInfo> jobList;//任务链表
    private String content;
    private LinearProgressView burningBar;
    private ImageView iv1, iv2, iv3, iv4, sv1, sv2, sv3, sv4, burnRush1, burnRush2, burnRush3;
    private int[] myIntegers = new int[4];
    private MissionInfo jobInitList[];

    public ConcentrateFragment(String content) {
        this.content = content;
    }

    //构造函数
    public ConcentrateFragment() {
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);


        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.concentrate_fragment, container, false);//实现fragment布局
        mContext = getActivity();
        iv1 = view.findViewById(R.id.BurnImageView2);//给燃度值设置监听
        iv2 = view.findViewById(R.id.BurnImageView3);
        iv3 = view.findViewById(R.id.BurnImageView4);
        iv4 = view.findViewById(R.id.BurnImageView5);
        sv1 = view.findViewById(R.id.SlienceImageView2);
        sv2 = view.findViewById(R.id.SlienceImageView3);
        sv3 = view.findViewById(R.id.SlienceImageView4);
        sv4 = view.findViewById(R.id.SlienceImageView5);
        burnRush1 = view.findViewById(R.id.BurningImageView);
        burnRush2 = view.findViewById(R.id.BurnImageView7);
        burnRush3 = view.findViewById(R.id.BurnImageView6);
        burningBar = view.findViewById(R.id.mylpv);
        addMission = view.findViewById(R.id.add_mission);
        mBackground = view.findViewById(R.id.missionList);
        mBackground.bringToFront();
        if (CustomerModel.isCustomer)//判断是否为游客模式决定是否与服务器连接
        {
            burningDegree = 0.0;
            silenceDegree = 0.0;
        } else {
            jobInitList = (MissionInfo[]) getActivity().getIntent().getSerializableExtra("missionList");
            burningDegree = getActivity().getIntent().getDoubleExtra("burning", 0);
            silenceDegree = getActivity().getIntent().getDoubleExtra("silence", 0);
            username = getActivity().getIntent().getStringExtra("username");
        }

        System.out.println("===========================================" + burningDegree + silenceDegree);
//        System.out.println("----------------------------------------------"+jobInitList.length+" "+jobInitList[0].jobName);
        initView();//初始化界面
        //添加监听实现活动跳转和消息回传
        addMission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), addmissionavtivity.class);
                startActivityForResult(intent, 1);
            }
        });
        return view;
    }

    //接收活动回传信息
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1://此情况为返回添加任务
                if (resultCode == RESULT_OK) {
                    String name = data.getStringExtra("mission_name");
                    String time = data.getStringExtra("mission_time");
//                    Toast.makeText(MainActivity.this,name+time+"",Toast.LENGTH_SHORT).show();
                    if (name.equals("") || time.equals("")) {
                        Toast.makeText(getActivity(), "任务内容为空！", Toast.LENGTH_SHORT).show();
                    } else {
                        missionNum = missionNum + 1;
                        View newMission = missionAdding(new MissionInfo(name, "无", Calendar.getInstance(), Calendar.getInstance(), Calendar.getInstance(), 0, 1, Integer.valueOf(time)));//设置任务信息;
                        newMission.bringToFront();
                        mBackground.addView(newMission);//加入控件
                        if (!CustomerModel.isCustomer) updateServerMissionList();
                        LoginActivity.mdt.getIa().JobCreate(name, Calendar.getInstance(), Integer.valueOf(time));
                    }// ---------------------------------------------
                }
                break;
            case 2://判断为专注返回值
                if (resultCode == RESULT_OK) {
                    double s = data.getDoubleExtra("silence", 0);
                    double b = data.getDoubleExtra("burning", 0);
//                    Toast.makeText(getActivity(), "测试",Toast.LENGTH_SHORT).show();
                    updateBurningBar((float) b, (float) s);
                }
                break;
            default:

        }
    }

    //向服务器更新任务列表
    private void updateServerMissionList() {
        JSONArray workList = new JSONArray();
        JSONObject update = new JSONObject();
        for (int i = 0; i < jobList.size(); i++) {
            workList.put(missionToJson(jobList.get(i)));
        }
        try {
            update.put("method", "userToDoUpdate");
            update.put("userAccount", username);
            update.put("currentTime", calendarToString(Calendar.getInstance()));
            update.put("currentIngtion", burningDegree);
            update.put("currentSilence", silenceDegree);
            update.put("tolgnition", 80);
            update.put("data", workList);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ServerClient s = null;
        try {
            s = new ServerClient(update.toString(), "POST", handler);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        System.out.println("----------------------------" + update.toString());
        new Thread(s).start();
    }

    //Calendar 转String
    public String calendarToString(Calendar c) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dateStr = sdf.format(c.getTime());
        return dateStr;
    }

    //任务对象转换JSON
    private JSONObject missionToJson(MissionInfo m) {
        JSONObject object = new JSONObject();

        try {
            object.put("jobName", m.jobName);
            object.put("jobSetDuration", m.jobDuration);
            object.put("jobAlreadyTime", m.jobAlreadyTime);
            object.put("jobCreateTime", calendarToString(m.jobCreateTime));
            object.put("jobStartTime", calendarToString(m.jobStartTime));
            object.put("jobEndTime", calendarToString(m.jobEndTime));
            object.put("jobType", m.jobType);
            object.put("jobScene", m.jobScene);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return object;
    }

    //初始化界面
    private void initView() {
        missionNum = 0;
        missionList = new LinkedList<RelativeLayout>();
        missionStartList = new LinkedList<ImageButton>();
        jobList = new LinkedList<MissionInfo>();
//        System.out.println("===-=---=-=--=-=-=-=-=-=-=-=-=-=-=-==-=-==-=-="+jobInitList.length);
        if (!CustomerModel.isCustomer)
            for (int i = 0; i < jobInitList.length; i++) {
//            System.out.println("----------------------------------"+i+" "+jobInitList[i].jobName);
                mBackground.addView(missionAdding(jobInitList[i]));
            }
        updateBurningBar((float) burningDegree, (float) silenceDegree);
    }

    //添加任务组件,
    private View missionAdding(final MissionInfo missionAdd) {
        final String fName = missionAdd.jobName, fTime = missionAdd.jobDuration + "";
        LayoutInflater flater = LayoutInflater.from(getActivity());
        View view = flater.inflate(R.layout.mission, null);
        String info = "已学习" + missionAdd.jobAlreadyTime + "/" + fTime + "分钟";
        TextView et1 = view.findViewById(R.id.mission_name);
        TextView et2 = view.findViewById(R.id.mission_info);
        RelativeLayout missionBtn = view.findViewById(R.id.mission_btn);
        ImageButton btn = view.findViewById(R.id.btn_mission_start);
        et1.setText(fName);
        et2.setText(info);
        //进入专注按钮添加监听事件
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), AbsorbActivity.class);
                Integer time = Integer.valueOf(fTime) * 60;
                intent.putExtra("mission", missionAdd);
                intent.putExtra("username", username);
                startActivityForResult(intent, 2);
                LoginActivity.mdt.getIa().JobStart(missionStartList.size() - 1, Calendar.getInstance());//---------------------------------------------
            }
        });
        missionList.add(missionBtn);//组件加入链表中，方便管理。
        missionStartList.add(btn);//开始任务按钮链表
        jobList.add(missionAdd);
        missionBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                showDialogFinish(view);
                return true;
            }
        });
        return view;
    }

    //删除页面
    public void showDialogFinish(View v) {
        DeleteDialog myDialogFinish = new DeleteDialog(v);
        myDialogFinish.setCancelable(false);
        myDialogFinish.show(getActivity().getSupportFragmentManager(), "是否退出");

    }

    public void buttonYesClicked(View v) {
        deleteMission(v);
    }

    public void buttonNoClicked() {
    }
    //进入任务专注

    //长按删除任务
    private void deleteMission(View v) {
        //删除操作
        if (v == null) {
            return;
        }
        // 判断第几个按钮触发了事件
        int index = -1;
        for (int i = 0; i < missionList.size(); i++) {
            if (missionList.get(i) == v) {
                index = i;
                break;
            }
        }
        if (index >= 0) {
            missionList.get(index).setVisibility(View.GONE);//删除控件
            missionList.remove(index);
            missionStartList.remove(index);
            jobList.remove(index);
            if (CustomerModel.isCustomer) {

            } else {
                updateServerMissionList();
            }

//           LoginActivity.mdt.getIa().JobDelete(index); //-------------------------------------------------------------------
        }
    }

    //更新燃读条读数与显示，判断燃还是冲
    public void updateBurningBar(double burning, double slience) {
        double po = burning / slience, count;
        System.out.println("-----------------------》po： " + po + ",burning:" + burning + ",silence" + slience);
        if (po > 1) po = 1;
        if (burning > slience) {
            count = burning;
        } else count = slience;
        if (burning > slience) {
            burnRush1.setBackgroundResource(R.drawable.moveword);
            burnRush2.setBackgroundResource(R.drawable.bwsb);
            burnRush3.setBackgroundResource(R.drawable.bws);
            setRushIntergers(burning);
            setSlienceIntergers(slience);
            burningBar.setPo((float) po);
            burningBar.setCurrentCount((float) count);
            burningBar.postInvalidate();
        } else {
            burnRush1.setBackgroundResource(R.drawable.burnword);
            burnRush2.setBackgroundResource(R.drawable.mwsb);
            burnRush3.setBackgroundResource(R.drawable.mws);
            setBurnIntergers(burning);
            setSlienceIntergers(slience);
            burningBar.setPo((float) po);
            burningBar.setCurrentCount((float) count);
            burningBar.postInvalidate();
        }

    }

    //设置默度读数显示
    private void setSlienceIntergers(double integer) {
        integer = integer * 100;
        int ins = (int) integer;
        myIntegers[0] = ins / 1000;//千位数
        myIntegers[1] = ins / 100 % 10;//百位数
        myIntegers[2] = ins % 100 / 10;//十位数
        myIntegers[3] = ins % 10;//个位数
        setSlienceBackgronud(sv1, myIntegers[0]);
        setSlienceBackgronud(sv2, myIntegers[1]);
        setSlienceBackgronud(sv3, myIntegers[2]);
        setSlienceBackgronud(sv4, myIntegers[3]);
    }

    //设置燃度读数显示
    private void setBurnIntergers(double integer) {
        integer = integer * 100;
        int ins = (int) integer;
        myIntegers[0] = ins / 1000;//千位数
        myIntegers[1] = ins / 100 % 10;//百位数
        myIntegers[2] = ins % 100 / 10;//十位数
        myIntegers[3] = ins % 10;//个位数
        setBurnBackgronud(iv1, myIntegers[0]);
        setBurnBackgronud(iv2, myIntegers[1]);
        setBurnBackgronud(iv3, myIntegers[2]);
        setBurnBackgronud(iv4, myIntegers[3]);
    }

    //设置燃度冲读数显示
    private void setRushIntergers(double integer) {
        integer = integer * 100;
        int ins = (int) integer;
        myIntegers[0] = ins / 1000;//千位数
        myIntegers[1] = ins / 100 % 10;//百位数
        myIntegers[2] = ins % 100 / 10;//十位数
        myIntegers[3] = ins % 10;//个位数
        setRushBackgronud(iv1, myIntegers[0]);
        setRushBackgronud(iv2, myIntegers[1]);
        setRushBackgronud(iv3, myIntegers[2]);
        setRushBackgronud(iv4, myIntegers[3]);
    }

    private void setBurnBackgronud(ImageView myIV, int myBG) {
        switch (myBG) {
            case 0:
                myIV.setBackgroundResource(R.drawable.mw0);
                break;
            case 1:
                myIV.setBackgroundResource(R.drawable.mw1);
                break;
            case 2:
                myIV.setBackgroundResource(R.drawable.mw2);
                break;
            case 3:
                myIV.setBackgroundResource(R.drawable.mw3);
                break;
            case 4:
                myIV.setBackgroundResource(R.drawable.mw4);
                break;
            case 5:
                myIV.setBackgroundResource(R.drawable.mw5);
                break;
            case 6:
                myIV.setBackgroundResource(R.drawable.mw6);
                break;
            case 7:
                myIV.setBackgroundResource(R.drawable.mw7);
                break;
            case 8:
                myIV.setBackgroundResource(R.drawable.mw8);
                break;
            case 9:
                myIV.setBackgroundResource(R.drawable.mw9);
                break;
            default:
                break;
        }
    }

    private void setRushBackgronud(ImageView myIV, int myBG) {
        switch (myBG) {
            case 0:
                myIV.setBackgroundResource(R.drawable.bw0);
                break;
            case 1:
                myIV.setBackgroundResource(R.drawable.bw1);
                break;
            case 2:
                myIV.setBackgroundResource(R.drawable.bw2);
                break;
            case 3:
                myIV.setBackgroundResource(R.drawable.bw3);
                break;
            case 4:
                myIV.setBackgroundResource(R.drawable.bw4);
                break;
            case 5:
                myIV.setBackgroundResource(R.drawable.bw5);
                break;
            case 6:
                myIV.setBackgroundResource(R.drawable.bw6);
                break;
            case 7:
                myIV.setBackgroundResource(R.drawable.bw7);
                break;
            case 8:
                myIV.setBackgroundResource(R.drawable.bw8);
                break;
            case 9:
                myIV.setBackgroundResource(R.drawable.bw9);
                break;
            default:
                break;
        }
    }

    private void setSlienceBackgronud(ImageView myIV, int myBG) {
        switch (myBG) {
            case 0:
                myIV.setBackgroundResource(R.drawable.sw0);
                break;
            case 1:
                myIV.setBackgroundResource(R.drawable.sw1);
                break;
            case 2:
                myIV.setBackgroundResource(R.drawable.sw2);
                break;
            case 3:
                myIV.setBackgroundResource(R.drawable.sw3);
                break;
            case 4:
                myIV.setBackgroundResource(R.drawable.sw4);
                break;
            case 5:
                myIV.setBackgroundResource(R.drawable.sw5);
                break;
            case 6:
                myIV.setBackgroundResource(R.drawable.sw6);
                break;
            case 7:
                myIV.setBackgroundResource(R.drawable.sw7);
                break;
            case 8:
                myIV.setBackgroundResource(R.drawable.sw8);
                break;
            case 9:
                myIV.setBackgroundResource(R.drawable.sw9);
                break;
            default:
                break;
        }
    }
}


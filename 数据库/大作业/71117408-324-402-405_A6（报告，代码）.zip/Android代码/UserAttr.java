package com.example.test;


/**
 * @author 杨宇
 * @function 社区界面利用得用户信息
 * @date 2019.9.10
 * @param
 * @return
 */
public class UserAttr {

    //展示用户信息所需数据
    double slient;
    double burnning;
    int weekLen;
    int monLen;
    int mId;


    UserAttr()
    {
        slient = 0;
        burnning = 0;
        weekLen = 0;
        monLen = 0;
        mId = 0;
    }

    UserAttr(double slient, double burnning, int len1, int len2, int id)
    {
        this.slient = slient;
        this.burnning = burnning;
        this.weekLen = len1;
        this.monLen = len2;
        this.mId = id;
    }

    double getSlient()
    {
        return slient;
    }
    double getBurnning()
    {
        return burnning;
    }
    int getWeekLen()
    {
        return weekLen;
    }
    int getMonLen()
    {
        return monLen;
    }
    int getmId()
    {
        return mId;
    }


}

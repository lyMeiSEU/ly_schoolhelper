/**
*添加任务界面
 *创建人：杜昕昱
 * 创建时间“2019.8.27
 * 功能：用于添加任务，生成添加任务界面，获取任务信息并回传
* */
package com.example.test;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.test.Client.ServerClient;

import java.net.MalformedURLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class addmissionavtivity extends AppCompatActivity {
private Handler handler=new Handler()
{
    @Override
    public void handleMessage(@NonNull Message msg) {
        super.handleMessage(msg);

    }
};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addmission);
        final EditText et_mission_name=findViewById(R.id.et1);
        final EditText et_mission_time=findViewById(R.id.et2);
        Button btn_mission=findViewById(R.id.mission_complete);
        btn_mission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view ) {
                String name=et_mission_name.getText().toString();
                String time=et_mission_time.getText().toString();
                setEditTextInhibitInputSpeChat(et_mission_name);
                setEditTextInhibitInputSpeChat(et_mission_time);
                if(name.equals("")||time.equals("")){
                    Toast.makeText(addmissionavtivity.this,"请输入任务内容！",Toast.LENGTH_SHORT).show();
                    System.out.println("+++++++++++++++++++无内容++++++++++++++++++");
                }
                else{
                    System.out.println("创建任务");
                    ServerClient s=null;
                    String method="";
                    try {
                        s=new ServerClient(method,"POST",handler);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    new Thread(s).start();
                    Intent intent=new Intent();
                    intent.putExtra("mission_name",name);
                    intent.putExtra("mission_time",time);
                    setResult(RESULT_OK,intent);
                    finish();
                }

            }
        });
    }

    /**
     * 禁止EditText输入特殊字符
     * @param editText
     */
    public static void setEditTextInhibitInputSpeChat(EditText editText){

        InputFilter filter=new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                String speChat="[`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
                Pattern pattern = Pattern.compile(speChat);
                Matcher matcher = pattern.matcher(source.toString());
                if(matcher.find())return "";
                else return null;
            }
        };
        editText.setFilters(new InputFilter[]{filter});
    }
    private void compileExChar(String str){

        String limitEx="[`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";

        Pattern pattern = Pattern.compile(limitEx);
        Matcher m = pattern.matcher(str);

        if( m.find()){
            Toast.makeText(this, "不允许输入特殊符号！", Toast.LENGTH_LONG).show();
        }

    }
}

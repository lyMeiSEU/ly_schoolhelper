/*
个人信息界面活动类
创始人：杜昕昱
创建时间：2019.08.30
功能：个人信息展示与修改，包括头像展示与修改以及其它内容的展示
 */
package com.example.test;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class PersonInfoActivity extends AppCompatActivity {

    CircleImageView imgPerson;//头像控件
    private String username;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_info);
        username = getIntent().getStringExtra("username");
        System.out.println("+++++++++++++++++++++++" + username);
        Toolbar toolbar = findViewById(R.id.info_toolbar);
        setSupportActionBar(toolbar);
        imgPerson = findViewById(R.id.imgPersonal);

        imgPerson.setClickable(true);

        imgPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) //设置点击头像更改
            {
                Intent intent = new Intent(Intent.ACTION_PICK, null);

                intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");

                startActivityForResult(intent, 99);


            }
        });
    }
//接收相册回传图片函数
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 99) {

            // 从相册返回的数据

            if (data != null) {

                // 得到图片的全路径

                Uri uri = data.getData();
                imgPerson.setImageURI(uri);
//                String path = UriTofilePath.getFilePathByUri(this, uri);
//                String url = "http://49.235.241.216:9999";
//                System.out.println(uri);
//                Bitmap photoBmp = null;
//                if (uri != null) {
//                    try {
//                        photoBmp = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
//                        String url="http://49.235.241.216:9999";
//                        String method="{'file': "+photoBmp+"}";
//                        ServerClient s=new ServerClient(url,method,"POST",handler);
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }//FileServer fileServer = new FileServer(url, path, username);
//              new Thread(fileServer).start();
            }

        }

    }
//设置返回按钮监听
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
//图片与图床服务器通讯类
class FileServer implements Runnable {
    private String url, file, newName;

    public FileServer(String url, String file, String newName) {
        this.url = url;
        this.file = file;
        this.newName = newName;
    }

    @Override
    public void run() {
        httpPost(url, file, newName);
        System.out.println("--------------------------------done-----------------------------");
    }

    /**
     * 往服务器上上传文本  比如log日志
     *
     * @param urlstr     请求的url
     * @param uploadFile log日志的路径
     *                   /mnt/shell/emulated/0/LOG/LOG.log
     * @param newName    log日志的名字 LOG.log
     * @return
     */
    public static void httpPost(String urlstr, String uploadFile, String newName) {
        String end = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";//边界标识
        int TIME_OUT = 10 * 1000;   //超时时间
        HttpURLConnection con = null;
        DataOutputStream ds = null;
        InputStream is = null;
        try {
            URL url = new URL(urlstr);
            con = (HttpURLConnection) url.openConnection();
            con.setReadTimeout(TIME_OUT);
            con.setConnectTimeout(TIME_OUT);
            /* 允许Input、Output，不使用Cache */
            con.setDoInput(true);
            con.setDoOutput(true);
            con.setUseCaches(false);

            // 设置http连接属性
            con.setRequestMethod("POST");//请求方式
            con.setRequestProperty("Connection", "Keep-Alive");//在一次TCP连接中可以持续发送多份数据而不会断开连接
            con.setRequestProperty("Charset", "UTF-8");//设置编码
            con.setRequestProperty("Content-Type",//multipart/form-data能上传文件的编码格式
                    "multipart/form-data;boundary=" + boundary);

            ds = new DataOutputStream(con.getOutputStream());
            ds.writeBytes(twoHyphens + boundary + end);
            ds.writeBytes("Content-Disposition: form-data; "
                    + "name=\"stblog\";filename=\"" + newName + "\"" + end);
            ds.writeBytes(end);

            // 取得文件的FileInputStream
            FileInputStream fStream = new FileInputStream(uploadFile);
            /* 设置每次写入1024bytes */
            int bufferSize = 1024;
            byte[] buffer = new byte[bufferSize];
            int length = -1;
            /* 从文件读取数据至缓冲区 */
            while ((length = fStream.read(buffer)) != -1) {
                /* 将资料写入DataOutputStream中 */
                ds.write(buffer, 0, length);
            }
            ds.writeBytes(end);
            ds.writeBytes(twoHyphens + boundary + twoHyphens + end);//结束

            fStream.close();
            ds.flush();
            /* 取得Response内容 */
            is = con.getInputStream();
            int ch;
            StringBuffer b = new StringBuffer();
            while ((ch = is.read()) != -1) {
                b.append((char) ch);
            }
            /* 将Response显示于Dialog */

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            /* 关闭DataOutputStream */
            if (ds != null) {
                try {
                    ds.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (con != null) {
                con.disconnect();
            }
        }
    }


}
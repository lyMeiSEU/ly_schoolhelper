package com.example.test;

import android.app.Dialog;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.LinkedList;


/**
 * @author 杨宇
 * @function 社区界面实现
 * 该界面下设置三个主按钮，可扩展（点击下拉）展示用户信息
 * 同时可点击用户条目展示详细用户信息
 * @date 2019.9.10
 * @param
 * @return
 */
public class SocialActivity extends AppCompatActivity {


    ImageButton activityFinish;

    //三个主窗口,包含用户条目
    private LinearLayout layoutGroup;
    private LinearLayout layoutTeam;
    private LinearLayout layoutPartner;

    //只包含主窗口信息的layout
    private LinearLayout layoutGroupNoEY;
    private LinearLayout layoutTeamNoEY;
    private LinearLayout layoutPartnerNoEY;

    //三个主窗口的动态布局，可动态放置用户条目
    private ExpandView expandViewGroup;
    private ExpandView expandViewTeam;
    private ExpandView expandViewPartner;



    private ImageView imgGroup;
    private ImageView imgTeam;
    private ImageView imgPartner;


    //屏蔽按钮
    private Switch teamSwitch;
    private Switch partnerSwitch;
    //添加好友按钮
    private ImageButton groupImgBtn;


    //窗口扩展时放大倍数
    private double magnification = 5;


    //已经加入动态布局的布局链表
    private LinkedList<View> userList;//任务链表
    private LinearLayout mBG;
    private RadioGroup TS;

    private ArrayList<UserAttr> groupUserList = new ArrayList<UserAttr>(10);
    private ArrayList<UserAttr> partnerUserList = new ArrayList<UserAttr>(10);

    private ArrayList<UserAttr> teamUserList = new ArrayList<UserAttr>(10);
    private ArrayList<UserAttr> teamUserList2 = new ArrayList<UserAttr>(10);
    private ArrayList<UserAttr> teamUserList3 = new ArrayList<UserAttr>(10);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        oncreateview();//连接布局
        ExpandView();//初始化调用

        getList();

    }

    /**
     * @author 杨宇
     * @function 得到相关数据，即用户初始化数据
     * @date 2019.9.10
     * @param
     * @return
     */
    void getList()
    {
        UserAttr user1 = new UserAttr(35.25, 15.89, 500, 3000, 711117414);
        UserAttr user2 = new UserAttr(34.25, 16.89, 450, 2500, 711117415);
        UserAttr user3 = new UserAttr(33.25, 17.89, 300, 2000, 711117416);
        UserAttr user4 = new UserAttr(32.25, 18.89, 400, 3500, 711117417);
        UserAttr user5 = new UserAttr(31.25, 19.89, 550, 2100, 711117418);
        UserAttr user6 = new UserAttr(30.25, 20.89, 600, 2200, 711117419);
        UserAttr user7 = new UserAttr(29.25, 21.89, 520, 2300, 711117420);
        UserAttr user8 = new UserAttr(28.25, 22.89, 50, 2200, 711117421);
        UserAttr user9 = new UserAttr(27.25, 23.89, 60, 2600, 711117422);

        groupUserList.add(user1);
        groupUserList.add(user2);
        groupUserList.add(user3);
        teamUserList.add(user4);
        teamUserList.add(user5);
        teamUserList.add(user6);
        partnerUserList.add(user7);
        partnerUserList.add(user8);
        partnerUserList.add(user9);

        teamUserList2.add(user2);
        teamUserList2.add(user4);
        teamUserList2.add(user6);
        teamUserList3.add(user3);
        teamUserList3.add(user6);
        teamUserList3.add(user9);

    }


    /**
     * @author 杨宇
     * @function 连接布局
     * 并且设置是否屏蔽按钮监听，当按钮状态变化时判断是否屏蔽id以保护隐私
     * @date 2019.9.10
     * @param
     * @return
     */
    private void oncreateview() {
        layoutGroup = (LinearLayout) findViewById(R.id.lygroup);
        layoutTeam = (LinearLayout) findViewById(R.id.lyteam);
        layoutPartner = (LinearLayout) findViewById(R.id.lypartner);

        layoutGroupNoEY = (LinearLayout) findViewById(R.id.lygroupNoEY);
        layoutTeamNoEY = (LinearLayout) findViewById(R.id.lyteamNoEY);
        layoutPartnerNoEY = (LinearLayout) findViewById(R.id.lypartnerNoEY);

        expandViewGroup = findViewById(R.id.evGroup);
        expandViewTeam = findViewById(R.id.evTeam);
        expandViewPartner = findViewById(R.id.evPartner);

        imgGroup = findViewById(R.id.groupimg);
        imgTeam = findViewById(R.id.teamimg);
        imgPartner = findViewById(R.id.partnerimg);

        teamSwitch = findViewById(R.id.teamSwitch);
        partnerSwitch = findViewById(R.id.partnerSwitch);
        groupImgBtn = findViewById(R.id.groupBtn);

        activityFinish = findViewById(R.id.communityReturn);

        activityFinish.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                finish();
            }
        });


        View view = LayoutInflater.from(this).inflate(R.layout.communitybg, null);
        userList = new LinkedList<View>();


        mBG = view.findViewById(R.id.communityBG);





        // 添加监听

        teamSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override

            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                int i = 0;
                if (isChecked) {

                    while (i < userList.size()) {
                        View view = userList.get(i);
                        TextView tv = view.findViewById(R.id.id_number);
                        tv.setText("******");
                        i++;
                    }

                } else {
                    int selected = TS.getCheckedRadioButtonId();
                    ArrayList<UserAttr> tranUserList = new ArrayList<UserAttr>();
                    switch (selected) {
                        case R.id.team1:
                            tranUserList = teamUserList;
                            break;
                        case R.id.team2:
                            tranUserList = teamUserList2;
                            break;
                        case R.id.team3:
                            tranUserList = teamUserList3;
                            break;
                    }
                    while (i < userList.size()) {
                        View view = userList.get(i);
                        TextView tv = view.findViewById(R.id.id_number);
                        tv.setText(String.valueOf(tranUserList.get(i).getmId()));
                        i++;
                    }

                }

            }

        });

        // 添加监听

        partnerSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override

            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int i = 0;
                if (isChecked){

                    while(i<userList.size())
                    {
                        View view = userList.get(i);
                        TextView tv = view.findViewById(R.id.id_number);
                        tv.setText("******");
                        i++;
                    }

                }else {

                    while(i<userList.size())
                    {
                        View view = userList.get(i);
                        TextView tv = view.findViewById(R.id.id_number);
                        tv.setText(String.valueOf(partnerUserList.get(i).getmId()));
                        i++;
                    }

                }

            }

        });



        TextView mtv1 = findViewById(R.id.textview_1);
        TextView mtv2 = findViewById(R.id.textview_2);
        TextView mtv3 = findViewById(R.id.textview_3);


//从asset 读取字体

        AssetManager mgr = getAssets();

//根据路径得到Typeface

        Typeface tf = Typeface.createFromAsset(mgr, "fonts/simkai.ttf");

        mtv1.setTypeface(tf);
        mtv2.setTypeface(tf);
        mtv3.setTypeface(tf);

    }

    /**
     @param view
     *点击添加好友
     * 输入用户id添加
     */
    // myClick为xml中指定的方法名，参数是View类型
    public void groupAddBtnOnClick(View view) {


        final Dialog mDialog= new Dialog(this, R.style.Theme_Light_Dialog);

        View v = LayoutInflater.from(this).inflate(R.layout.addpartner_dialog, null);


        //获得dialog的window窗口

        Window window = mDialog.getWindow();

        //设置dialog在屏幕底部

        window.setGravity(Gravity.CENTER);

        //设置dialog弹出时的动画效果，从屏幕底部向上弹出

        window.setWindowAnimations(R.style.dialogStyle);



        //获得window窗口的属性

        WindowManager.LayoutParams lp = window.getAttributes();

        //设置窗口宽度为充满全屏

        lp.width = WindowManager.LayoutParams.MATCH_PARENT;

        //设置窗口高度为包裹内容

        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        //将设置好的属性set回去

        window.setAttributes(lp);

        //将自定义布局加载到dialog上

        mDialog.setContentView(v);

        Button dialogReturn = v.findViewById(R.id.dialog_return);
        final EditText idReturn = v.findViewById(R.id.id_return);

        dialogReturn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                String id2String = idReturn.getText().toString();
                int id = Integer.valueOf(id2String);
                UserAttr newPartner = new UserAttr(0,0,0,0,id);

                groupUserList.add(newPartner);

                userList.clear();
                expandViewGroup.removeAllViews();

                leadingUserIn(groupUserList, expandViewGroup, false);

                mDialog.dismiss();

            }
        });

        mDialog.show();

    }


    /**
     @param view
      *可扩展view初始化调用，为三个主控件设置监听
     * 当点击时扩大布局并且添加用户条目
     * 再次点击时撤销所有用户条目并且将布局缩小到原来大小
      *
     */
    public void ExpandView() {

        //第一窗口的点击监听
        layoutGroupNoEY.setClickable(true);

        layoutGroupNoEY.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //首先收回其它布局
                if(expandViewTeam.isExpand())
                {
                    userList.clear();
                    teamSwitch.setChecked(false);
                    teamSwitch.setClickable(false);
                    teamSwitch.setVisibility(View.INVISIBLE);

                    //布局缩小到正常倍数
                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutTeam.getLayoutParams();
                    params_1.height /= magnification;
                    layoutTeam.setLayoutParams(params_1);

                    expandViewTeam.removeAllViews();

                    //动态布局收回动画
                    expandViewTeam.collapse();
                    //改变箭头指向
                    imgTeam.setBackground(getResources().getDrawable(R.mipmap.mdownimgt));
                }

                if(expandViewPartner.isExpand())
                {

                    userList.clear();
                    partnerSwitch.setChecked(false);
                    partnerSwitch.setClickable(false);
                    partnerSwitch.setVisibility(View.INVISIBLE);

                    //布局缩小
                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutPartner.getLayoutParams();
                    params_1.height /= magnification;
                    layoutPartner.setLayoutParams(params_1);

                    expandViewPartner.removeAllViews();

                    //动态布局收回
                    expandViewPartner.collapse();

                    imgPartner.setBackground(getResources().getDrawable(R.mipmap.mdownimgp));
                }

                if (expandViewGroup.isExpand()) {

                    userList.clear();
                    groupImgBtn.setClickable(false);
                    groupImgBtn.setVisibility(View.INVISIBLE);

                    userList.clear();

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutGroup.getLayoutParams();
                    params_1.height /= magnification;
                    layoutGroup.setLayoutParams(params_1);

                    expandViewGroup.removeAllViews();

                    expandViewGroup.collapse();

                    imgGroup.setBackground(getResources().getDrawable(R.mipmap.mdownimgg));
                } else {

                    groupImgBtn.setClickable(true);
                    groupImgBtn.setVisibility(View.VISIBLE);

                    leadingUserIn(groupUserList, expandViewGroup, false);
                    //布局放大
                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutGroup.getLayoutParams();
                    System.out.println(params_1.height);
                    params_1.height *= magnification;
                    layoutGroup.setLayoutParams(params_1);
                    expandViewGroup.expand();

                    imgGroup.setBackground(getResources().getDrawable(R.mipmap.mupimgg));
                }
            }
        });


        //设置第二窗口点击监听
        layoutTeamNoEY.setClickable(true);
        layoutTeamNoEY.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(expandViewGroup.isExpand())
                {
                    userList.clear();

                    groupImgBtn.setClickable(false);
                    groupImgBtn.setVisibility(View.INVISIBLE);

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutGroup.getLayoutParams();
                    params_1.height /= magnification;
                    layoutGroup.setLayoutParams(params_1);

                    expandViewGroup.removeAllViews();

                    expandViewGroup.collapse();

                    imgGroup.setBackground(getResources().getDrawable(R.mipmap.mdownimgg));
                }
                if(expandViewPartner.isExpand())
                {
                    userList.clear();
                    partnerSwitch.setChecked(false);
                    partnerSwitch.setClickable(false);
                    partnerSwitch.setVisibility(View.INVISIBLE);

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutPartner.getLayoutParams();
                    params_1.height /= magnification;
                    layoutPartner.setLayoutParams(params_1);

                    expandViewPartner.removeAllViews();

                    expandViewPartner.collapse();

                    imgPartner.setBackground(getResources().getDrawable(R.mipmap.mdownimgp));
                }


                if (expandViewTeam.isExpand()) {
                    teamSwitch.setChecked(false);
                    teamSwitch.setClickable(false);
                    teamSwitch.setVisibility(View.INVISIBLE);

                    userList.clear();

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutTeam.getLayoutParams();
                    params_1.height /= magnification;
                    layoutTeam.setLayoutParams(params_1);

                    expandViewTeam.removeAllViews();

                    expandViewTeam.collapse();

                    imgTeam.setBackground(getResources().getDrawable(R.mipmap.mdownimgt));

                } else {


                    teamSwitch.setClickable(true);
                    teamSwitch.setVisibility(View.VISIBLE);

                    leadingUserIn(teamUserList, expandViewTeam, true);

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutTeam.getLayoutParams();
                    System.out.println(params_1.height);
                    params_1.height *= magnification;
                    layoutTeam.setLayoutParams(params_1);
                    expandViewTeam.expand();

                    imgTeam.setBackground(getResources().getDrawable(R.mipmap.mupimgt));
                }
            }
        });




        layoutPartnerNoEY.setClickable(true);
        layoutPartnerNoEY.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(expandViewGroup.isExpand())
                {
                    userList.clear();

                    groupImgBtn.setClickable(false);
                    groupImgBtn.setVisibility(View.INVISIBLE);

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutGroup.getLayoutParams();
                    params_1.height /= magnification;
                    layoutGroup.setLayoutParams(params_1);

                    expandViewGroup.removeAllViews();

                    expandViewGroup.collapse();

                    imgGroup.setBackground(getResources().getDrawable(R.mipmap.mdownimgg));
                }
                if(expandViewTeam.isExpand())
                {
                    userList.clear();

                    teamSwitch.setChecked(false);
                    teamSwitch.setClickable(false);
                    teamSwitch.setVisibility(View.INVISIBLE);

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutTeam.getLayoutParams();
                    params_1.height /= magnification;
                    layoutTeam.setLayoutParams(params_1);

                    expandViewTeam.removeAllViews();

                    expandViewTeam.collapse();

                    imgTeam.setBackground(getResources().getDrawable(R.mipmap.mdownimgt));
                }


                if (expandViewPartner.isExpand()) {
                    partnerSwitch.setChecked(false);
                    partnerSwitch.setClickable(false);
                    partnerSwitch.setVisibility(View.INVISIBLE);

                    userList.clear();

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutPartner.getLayoutParams();
                    params_1.height /= magnification;
                    layoutPartner.setLayoutParams(params_1);

                    expandViewPartner.removeAllViews();

                    expandViewPartner.collapse();

                    imgPartner.setBackground(getResources().getDrawable(R.mipmap.mdownimgp));
                } else {

                    partnerSwitch.setClickable(true);
                    partnerSwitch.setVisibility(View.VISIBLE);

                    leadingUserIn(partnerUserList, expandViewPartner, false);

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) layoutPartner.getLayoutParams();
                    System.out.println(params_1.height);
                    params_1.height *= magnification;
                    layoutPartner.setLayoutParams(params_1);
                    expandViewPartner.expand();

                    imgPartner.setBackground(getResources().getDrawable(R.mipmap.mupimgp));
                }
            }
        });
    }



    /**
     @param ArrayList<UserAttr>
     @param ExpandView
     @param isTeam
     *添加用户条目，加入isTeam判断由于团队下可切换
     * 因此加入radioGroup监听判断是否切换团队
     * 当切换团队时，重新加入用户条目
     */
    private void leadingUserIn(ArrayList<UserAttr> list, final ExpandView EV, boolean isTeam)
    {
        mBG.removeAllViews();

        int i = 0;

        if(isTeam){
            LayoutInflater flater = LayoutInflater.from(this);
            View view = flater.inflate(R.layout.teamsofswitch, null);
            mBG.addView(view);
            TS = (RadioGroup)view.findViewById(R.id.teamRadioGroup);

            //切换团队设置监听
            ((RadioGroup) TS).setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup radioGroup, int i) {
                    int count = userList.size();
                    userList.clear();
                    teamSwitch.setChecked(false);
                    int j = 0;
                    //一下为三个团队
                    switch (i){
                        case R.id.team1:
                            mBG.removeViews(1,count);
                            j = 0;
                            while (j < teamUserList.size()) {
                                View newMission = missionAdding(teamUserList.get(j),j);//设置任务信息;
                                newMission.bringToFront();
                                mBG.addView(newMission);//加入控件
                                ++j;
                            }
                            EV.removeAllViews();
                            EV.setContentView(mBG.getRootView());
                            break;
                        case R.id.team2:
                            mBG.removeViews(1,count);
                            j = 0;
                            while ( j < teamUserList2.size()) {
                                View newMission = missionAdding(teamUserList2.get(j),j);//设置任务信息;
                                newMission.bringToFront();
                                mBG.addView(newMission);//加入控件
                                ++j;
                            }
                            EV.removeAllViews();
                            EV.setContentView(mBG.getRootView());
                            break;
                        case R.id.team3:
                            mBG.removeViews(1,count);
                            j = 0;
                            while (j < teamUserList3.size()) {
                                View newMission = missionAdding(teamUserList3.get(j),j);//设置任务信息;
                                newMission.bringToFront();
                                mBG.addView(newMission);//加入控件
                                ++j;
                            }
                            EV.removeAllViews();
                            EV.setContentView(mBG.getRootView());
                            break;
                        default:
                            break;

                    }

                }
            });


        }


        while (i < list.size()) {
            View newMission = missionAdding(list.get(i),i);//设置任务信息;
            newMission.bringToFront();
            mBG.addView(newMission);//加入控件
            ++i;
        }
        EV.setContentView(mBG.getRootView());
    }



    /**
     * @author 杨宇
     * @function 导入用户信息
     * @date 2019.9.10
     * @param
     * @return
     */
    private void leadingUserInfo(UserAttr mAttr, ExpandView EV)
    {
        View view = LayoutInflater.from(this).inflate(R.layout.attribute, null);


        TextView mSlient = view.findViewById(R.id.attr_Silent);
        TextView mBurnning = view.findViewById(R.id.attr_Burnning);
        TextView mWeekLen = view.findViewById(R.id.attr_WeekLen);
        TextView mMonLen = view.findViewById(R.id.attr_MonLen);

        ProgressBar msBar = view.findViewById(R.id.nowSilent);
        ProgressBar mbBar = view.findViewById(R.id.nowBurnning);
        ProgressBar mwlBar = view.findViewById(R.id.nowWeekLen);
        ProgressBar mmlBar = view.findViewById(R.id.nowMonLen);

        mSlient.setText("默度："+String.valueOf(mAttr.getSlient())+"%");
        mBurnning.setText("燃度："+String.valueOf(mAttr.getBurnning())+"%");
        mWeekLen.setText("周时长："+String.valueOf(mAttr.getWeekLen()/60)+"时"+String.valueOf(mAttr.getWeekLen()%60)+"分");
        mMonLen.setText("月时长："+String.valueOf(mAttr.getMonLen()/60)+"时"+String.valueOf(mAttr.getMonLen()%60)+"分");

        msBar.setProgress((int)(mAttr.getSlient()*100));
        mbBar.setProgress((int)(mAttr.getBurnning()*100));
        mwlBar.setProgress(mAttr.getWeekLen());
        mmlBar.setProgress(mAttr.getMonLen());


        EV.setContentView(view);
    }


    /**
     * @author 杨宇
     * @function 加入用户条目
     * @date 2019.9.10
     * @param
     * @return
     */
    private View missionAdding(final UserAttr mUser,int index) {


        LayoutInflater flater = LayoutInflater.from(this);
        View view = flater.inflate(R.layout.userentry, null);
        TextView et1 = view.findViewById(R.id.id_number);
        final LinearLayout missionBtn = view.findViewById(R.id.userInfo);
        CardView mCV = view.findViewById(R.id.mCardView);
        final ExpandView expandView = view.findViewById(R.id.evGroup);
        final ImageView image_sk = view.findViewById(R.id.img_shrink);
        ImageView mHeadImg = view.findViewById(R.id.mheadimg);
        TextView mRankNumber = view.findViewById(R.id.rankNumber);

        missionBtn.setClickable(true);


        mCV.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                if (expandView.isExpand()) {

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) missionBtn.getLayoutParams();
                    params_1.height /= 4;
                    missionBtn.setLayoutParams(params_1);

                    expandView.removeAllViews();

                    expandView.collapse();
                    image_sk.setImageDrawable(getResources().getDrawable(R.mipmap.mdownimg));
                } else {

                    leadingUserInfo(mUser,expandView);

                    LinearLayout.LayoutParams params_1 = (LinearLayout.LayoutParams) missionBtn.getLayoutParams();
                    System.out.println(params_1.height);
                    params_1.height *= 4;
                    missionBtn.setLayoutParams(params_1);
                    expandView.expand();
                    image_sk.setImageDrawable(getResources().getDrawable(R.mipmap.mupimg));
                }
            }

        });


        switch(index)
        {
            case 0:
                mHeadImg.setImageDrawable(getResources().getDrawable(R.mipmap.headimg1));
                break;
            case 1:
                mHeadImg.setImageDrawable(getResources().getDrawable(R.mipmap.headimg3));
                break;
            case 2:
                mHeadImg.setImageDrawable(getResources().getDrawable(R.mipmap.headimg4));
                break;
            case 3:
                mHeadImg.setImageDrawable(getResources().getDrawable(R.mipmap.headimg6));
                break;
            case 4:
                mHeadImg.setImageDrawable(getResources().getDrawable(R.mipmap.headimg7));
                break;
            case 5:
                mHeadImg.setImageDrawable(getResources().getDrawable(R.mipmap.headimg8));
                break;
                default:
                    break;
        }

        mRankNumber.setText(String.valueOf(userList.size()+1)+"名");
        et1.setText(String.valueOf(mUser.getmId()));
        //按钮添加监听事件

        userList.add(view);//组件加入链表中，方便管理。

        return view;
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_community, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            return true;
        }

        return super.onOptionsItemSelected(item);
    }



}

/**
 * 滑动界面活动类
创建时间：2019.8.28
创建人：杜昕昱
功能描述：活动界面活动上放置任务界面和其他界面两个fragment，通过滑动页面进行切换，同过BurningFragmentPagerAdapter对页面滑动事件进行管理。
 */
package com.example.test;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
public class SwitchActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, ViewPager.OnPageChangeListener{

    private RadioGroup rg_bar;//底部切换fragment的两个按钮，分别是专注和其他采用radiogroup中的两个radiobutton实现
    private RadioButton rb_con, rb_other;
    private ViewPager vpager;//viewpager中放置两个fragment，通过滑动进行切换
    private BurningFragmentPagerAdapter bAdapter;//管理页面滑动切换
    private IgnitionAlgorithm ia;//燃度算法
    public static final int PAGE_ONE = 0, PAGE_TWO = 1;//设置页面编号

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_switch);
        bAdapter = new BurningFragmentPagerAdapter(getSupportFragmentManager());
        bindViews();//先设置所有fragment为不可见，在对当前的页面进行更新
        rb_con.setChecked(true);
    }
//将所有页面设置为不可见
    private void bindViews() {
        rb_con = findViewById(R.id.con_rbtn);
        rb_other = findViewById(R.id.other_rbtn);
        rg_bar = findViewById(R.id.bar);
        rg_bar.setOnCheckedChangeListener(this);
        vpager = findViewById(R.id.vpager);
        vpager.setAdapter(bAdapter);
        vpager.setCurrentItem(0);
        vpager.addOnPageChangeListener(this);

    }
//设置radiobutton的监听，当选中按钮时切换页面。
    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        switch (i) {
            case R.id.con_rbtn:
                vpager.setCurrentItem(PAGE_ONE);
                break;
            case R.id.other_rbtn:
                vpager.setCurrentItem(PAGE_TWO);

                break;
        }
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {
    }
//监听页面，使得当前页面对应的按钮设置为确认
    @Override
    public void onPageScrollStateChanged(int state) {
        if (state == 2) {
            switch (vpager.getCurrentItem()) {
                case PAGE_ONE:
                    rb_con.setChecked(true);
                    break;
                case PAGE_TWO:
                    rb_other.setChecked(true);
                    break;
            }
        }
    }
}


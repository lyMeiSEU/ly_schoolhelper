package com.example.test;


import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;


/**
 * @author 杨宇
 * @function 自定义条形进度条实现
 * @date 2019.9.10
 * @param
 * @return
 */
public class LinearProgressView extends View {
    /**
     * 渐变颜色段
     */
    private Float po = 0F;

    private int[] SECTION_COLORS = {getResources().getColor(R.color.myColor1), getResources().getColor(R.color.myColor2)};

    private float maxCount = 100;

    private float currentCount = 10;

    private Paint mPaint;
    private Paint mPaintBg;
    private int mWidth, mHeight;

    private RectF rectBg = new RectF();  // 外框背景
    private RectF rectProgressBg = new RectF();//进度条
    private LinearGradient shader;

    public LinearProgressView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    public LinearProgressView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public LinearProgressView(Context context) {
        super(context);
        initView(context);
    }

    private void initView(Context context) {
        mPaint = new Paint();
        mPaintBg = new Paint();
    }

    public void setPo(float f)
    {
        this.po = f;
    }

    public float getPo()
    {
        return po;
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        this.setRotation(270);
        mHeight = bottom - top;
        mWidth = right - left;
        rectBg.set(0, 0, mWidth, mHeight);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float[] position = new float[]{po,1};
        shader = new LinearGradient(0, 0, mWidth*(currentCount/maxCount), 0, SECTION_COLORS, position, Shader.TileMode.CLAMP);

        mPaint.setShader(shader);
        mPaint.setAntiAlias(true);
        mPaintBg.setAntiAlias(true);
        mPaintBg.setStrokeWidth(20);
        mPaintBg.setColor(getResources().getColor(R.color.myBg2));
        mPaintBg.setStyle(Paint.Style.STROKE);
        // mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStyle(Paint.Style.STROKE);




        //绘制进度条外侧边框
        int round = mHeight * 1 / 3;
        canvas.drawRoundRect(rectBg, round, round, mPaintBg);


        //绘制进度条
        mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        float section = currentCount / maxCount;
        Log.i("currentCount","count:" + currentCount) ;
        int pl = (int) (mWidth * (section));
        rectProgressBg.set(0, 12, pl, mHeight-12);

        canvas.drawRoundRect(rectProgressBg, round, round, mPaint);
    }

    /*
     * 设置最大的进度值
     */
    public void setMaxCount(float maxCount) {
        this.maxCount = maxCount;
    }

    /**
     * 设置当前的进度值
     * 2s 的渐变动画 变加速
     */
    public void setCurrentCount( float progress) {
        float last = this.currentCount;
        this.currentCount = progress > maxCount ? maxCount : progress;
        ValueAnimator animator = new ValueAnimator().ofFloat(last,progress);
        animator.setInterpolator( new AccelerateInterpolator());
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                currentCount  = (float) animation.getAnimatedValue();
                postInvalidate();
            }
        });
        animator.setDuration(2000);
        animator.start();

    }

    public float getMaxCount() {
        return maxCount;
    }

    public float getCurrentCount() {
        return currentCount;
    }

}

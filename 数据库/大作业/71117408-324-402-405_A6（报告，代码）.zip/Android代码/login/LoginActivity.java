package com.example.test.login;
/**
 * Author 71117415-喻泽弘
 * Date 2019.8.21
 * Function 登录界面，创建登录界面，判断登录的结果，提供游客模式等多项功能
 * */

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.test.Client.ServerClient;
import com.example.test.CustomerModel.CustomerModel;
import com.example.test.MissionInfo;
import com.example.test.MyDataThread;
import com.example.test.R;
import com.example.test.SwitchActivity;
import com.example.test.data.model.Answer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class LoginActivity extends AppCompatActivity {
    //用户名
    String username;
    //密码
    String password;
    //计算重连服务器的次数
    int count=0;
    //活动通讯
    Intent intent_mission;
    //游客模式入口
    private TextView customerView;
    static public MyDataThread mdt;
    /*验证码*/
    private ImageView idCode;
    private LoginViewModel loginViewModel;
    //处理登录结果的handler信息处理工具
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);

            /*Answer.answer=msg.obj.toString();
            System.out.println(Answer.answer);
            System.out.println("Get From subThread"+msg.toString());
            loginViewModel.login(username,
                    password);*/
            switch (msg.what) {
                case 1:
                    Answer.answer = msg.obj.toString();
                    System.out.println(Answer.answer);
                    System.out.println("Get From subThread" + msg.toString());
                    loginViewModel.login(username,
                            password);
                    break;
                case 2:
                    Bitmap bitmap = (Bitmap) msg.obj;
                    System.out.println("---------------code-----------");
                    idCode.setImageBitmap(bitmap);
                    break;
                case 3:
                    System.out.println(msg.obj.toString() + " Please input again.");
                    break;
                case 4:
                    Answer.answer = msg.obj.toString();
                    System.out.println(Answer.answer);
                    System.out.println("Get From subThread" + msg.toString());
                    loginViewModel.login(username,
                            password);
                    break;
                default:
                    break;
            }
        }
    };
    //消息处理handler
    private Handler handler1 = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            JSONArray missionList = new JSONArray();
            //System.out.println("--------------------------打印任务信息：" + msg.obj.toString());
            try {
                missionList = new JSONArray(msg.obj.toString());
                System.out.println("========================" + missionList.toString());
            } catch (JSONException e) {
                System.out.println("-------------------------==========error" + e);
                e.printStackTrace();
            }
            int n = missionList.length();
            System.out.println("--------------------------任务列表长度---------------------------"+n);
            MissionInfo jobList[] = new MissionInfo[n-1];
            Double burning=0.00,silence=0.00;
            if(n>0) {
                try {
                    JSONObject jsonIgntion = missionList.getJSONObject(0);
                    burning = jsonIgntion.getDouble("currentIngtion");
                    silence = jsonIgntion.getDouble("currentSilence");
                    burning = 0.00;
                    silence = 30.9321;
                    mdt = new MyDataThread(LoginActivity.this,silence,burning);
                    System.out.println("---------------------------" + burning + silence);
                    JSONObject jsonObject0 = missionList.getJSONObject(1);
                    System.out.println("------------------------------------print------------------------------------" + jsonObject0);
                    if (jsonObject0 == null) n = 1;
                    for (int i = 1; i < n; i++) {
                        JSONObject jsonObject = missionList.getJSONObject(i);
                        jobList[i - 1] = jsonToMission(jsonObject);
                    }
                } catch (JSONException e) {
                    System.out.println("=============--------error" + e);
                    e.printStackTrace();
                }
            }
            intent_mission.putExtra("burning",burning);
            intent_mission.putExtra("silence",silence);
            intent_mission.putExtra("missionList", jobList);
            intent_mission.putExtra("username",username);
            startActivity(intent_mission);
            finish();
        }
    };

    //JSON对象转换成任务对象返回
    public MissionInfo jsonToMission(JSONObject o) {
        String jobName, jobScene;
        Calendar jobCreateTime, jobStartTime, jobEndTime;
        int jobType, jobDuration, jobAlreadyTime;
        MissionInfo m = new MissionInfo();
        try {
            jobName = o.getString("jobName");
            jobScene = o.getString("jobScene");
            jobCreateTime = stringToCalendar(o.getString("jobCreateTime"));
            jobStartTime = stringToCalendar(o.getString("jobStartTime"));
            jobEndTime = stringToCalendar(o.getString("jobEndTime"));
            jobType = o.getInt("jobType");
            jobDuration = o.getInt("jobSetDuration");
            jobAlreadyTime = o.getInt("jobAlreadyTime");
            m = new MissionInfo(jobName, jobScene, jobCreateTime, jobStartTime, jobEndTime, jobAlreadyTime, jobType, jobDuration);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return m;
    }

    //String转Calendar
    public Calendar stringToCalendar(String d) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {
            date = sdf.parse(d);
        } catch (ParseException e) {
            System.out.println("----------------->error" + e);
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar;
    }
    //动画的layout
    LinearLayout mAnimLinearLayout;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //getSupportActionBar().hide();
        setContentView(R.layout.activity_login);

        customerView=findViewById(R.id.customerModel);
        //游客模式的监听
        customerView.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View view) {
                CustomerModel.isCustomer=true;
                Intent intent=new Intent(LoginActivity.this,SwitchActivity.class);
                startActivity(intent);
            }
        });
        mAnimLinearLayout = findViewById(R.id.mAnim);
        AlphaAnimation alphaAnimation = new AlphaAnimation((float) 0.1, 1);
        alphaAnimation.setDuration(2000);//设定动画时间
        //添加动画监听
        alphaAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }
            @Override
            public void onAnimationRepeat(Animation animation) {

            }
            @Override
            public void onAnimationEnd(Animation animation) {
                mAnimLinearLayout.setVisibility(View.GONE);
            }
        });
        mAnimLinearLayout.setAnimation(alphaAnimation);
        //设置动画的可见性
        mAnimLinearLayout.setVisibility(View.VISIBLE);


        //服务器通讯线程
        mdt = new MyDataThread(this);
        System.out.println("创建数据库、偏好表、燃度值存储"); //创建数据库、偏好表、燃度值存储
        ServerClient s = null;
        try {
            s = new ServerClient("", "GET", handler);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        new Thread(s).start();
        loginViewModel = ViewModelProviders.of(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        /*用户名文本编辑*/
        final EditText usernameEditText = findViewById(R.id.username);
        /*密码文本编辑*/
        final EditText passwordEditText = findViewById(R.id.password);
        /*验证码文本编辑*/
        final EditText idcodeEditText = findViewById(R.id.identification);
        /*登录按钮*/
        final Button loginButton = findViewById(R.id.login);
        /*进度条*/
        final ProgressBar loadingProgressBar = findViewById(R.id.loading);
        idCode = findViewById(R.id.idCode);
        /*观察UI线程的改变*/
        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                /*setEnabled()函数设置控件是否可以点击 true：可点击 false：不可点击*/
                //如果登录格式正确便可以点击登录按钮
                loginButton.setEnabled(loginFormState.isDataValid());
                //loginButton.setEnabled(false);
                if (loginFormState.getUsernameError() != null) {
                    //输出登录名格式问题
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    //输出登录密码格式问题
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));
                }

            }
        });
        //观察登录的结果
        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;
                }
                //这里更改进度条
                loadingProgressBar.setVisibility(View.GONE);
                //登录异常
                if (loginResult.getError() != null) {
                    //每50次重连显示一次Toast
                    if(count%50==0)
                        showLoginFailed(loginResult.getError());
                    ServerClient s = null;
                    try {
                        s = new ServerClient("", "GET", handler);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    new Thread(s).start();
                    count++;
                }
                //登录成功
                if (loginResult.getSuccess() != null) {
                    updateUiWithUser(loginResult.getSuccess());
                    intent_mission = new Intent(LoginActivity.this, SwitchActivity.class);
                    ServerClient s1 = null;
                    System.out.println("---------------------------------------" + username);
                    String method = "\"{\\\"method\\\":\\\"getToDoList\\\",\\\"userAccount\\\":\\\"" + username + "\\\"}\"";
                    try {
                        s1 = new ServerClient(method, "POST", handler1);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    new Thread(s1).start();
                }
                setResult(Activity.RESULT_OK);
                //Complete and destroy login activity once successful
                //登录界面一旦成果就取消
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        /*该控件并不是在我们编辑TextView时触发，也不是在我们点击TextView时触发，而是我们编辑完TextView时触发
         * 即按下完成按钮之后，撤回软键盘*/
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    /*loginViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString());*/
                    //return true;
                }
                return false;
            }
        });
        usernameEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    /*loginViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString());*/
                    //return true;
                }
                return false;
            }
        });
        //验证码文本添加监听
        idcodeEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    /*loginViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString());*/
                    //return true;
                }
                return false;
            }
        });
        //登录按钮添加监听
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //加载条设置为可见
                loadingProgressBar.setVisibility(View.VISIBLE);
                username = usernameEditText.getText().toString();
                password = passwordEditText.getText().toString();
                System.out.println("use");
                //定义传输的方法
                String method = "\"{\\\"method\\\":\\\"userLogin\\\",\\\"data\\\":[{\\\"userAccount\\\": \\\"" + username + "\\\", " +
                        "\\\"userPassword\\\": \\\"" + password + "\\\",\\\"verCode\\\": \\\"" + idcodeEditText.getText().toString() + "\\\",\\\"userType\\\":\\\"normal\\\"}]}\"";
                ServerClient s = null;
                try {
                    s = new ServerClient(method, "POST", handler);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                new Thread(s).start();
                //判断登录请求
            }
        });
    }
    //显示登录成功的Toast
    private void updateUiWithUser(LoggedInUserView model) {
        String welcome = getString(R.string.welcome);
        // TODO : initiate successful logged in experience
        Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();
    }
    //显示登录失败的Toast
    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }
}

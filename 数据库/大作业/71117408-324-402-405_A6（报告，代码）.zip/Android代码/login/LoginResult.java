package com.example.test.login;

import androidx.annotation.Nullable;

/**
 * Authentication result : success (user details) or error message.
 * Function 创建登录成果、失败、异常的对象
 * 返回该对象用于UI线程判断登录结果
 * Date 2019.8.21
 * Author 71117415-喻泽弘
 */
class LoginResult {
    @Nullable
    private LoggedInUserView success;
    @Nullable
    private Integer error;

    LoginResult(@Nullable Integer error) {
        this.error = error;
    }

    LoginResult(@Nullable LoggedInUserView success) {
        this.success = success;
    }

    @Nullable
    LoggedInUserView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }
}

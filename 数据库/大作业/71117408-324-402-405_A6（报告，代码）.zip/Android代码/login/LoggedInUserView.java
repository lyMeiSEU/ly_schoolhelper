package com.example.test.login;

/**
 * Author 71117415-喻泽弘
 * function 传递信息给ui线程的工具类
 * Date 2019.8.21
 * Class exposing authenticated user details to the UI.
 */
class LoggedInUserView {
    private String displayName;
    //... other data fields that may be accessible to the UI

    LoggedInUserView(String displayName) {
        this.displayName = displayName;
    }

    String getDisplayName() {
        return displayName;
    }
}

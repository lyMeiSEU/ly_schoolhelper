package com.example.test;

import android.content.Context;
import android.widget.TextView;

import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.utils.MPPointF;


public class DetailsMarkerView extends MarkerView {
    /**
     * Constructor. Sets up the MarkerView with a custom layout resource.
     *
     * @param context
     * @param layoutResource the layout resource to use for the MarkerView
     */
    private TextView mTvMonth;
    private TextView mTvChart1;
    public DetailsMarkerView(Context context, int layoutResource) {
        super(context,layoutResource);
        mTvMonth=findViewById(R.id.tv_chart_month);
        mTvChart1=findViewById(R.id.tv_chart_1);
    }

    //每次重绘，会调用此方法刷新数据
    @Override
    public void refreshContent(Entry e, Highlight highlight) {
        super.refreshContent(e, highlight);
        try {
            if(e.getY()<0)
            {
                mTvChart1.setText("暂无数据");
            }else
            {
                mTvChart1.setText(e.getY()+"h");
            }
            mTvMonth.setText("学习时长");
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        super.refreshContent(e, highlight);
    }
    //-(width)/2布局水平居中，-(height)布局显示在圆点的正上方
    @Override
    public MPPointF getOffset()
    {
        return new MPPointF(-(getWidth()/2),-getHeight());
    }
}

package com.example.test;
/**
 * 任务信息类
 * 创始人：杜昕昱
 * 创建时间：2019.8.25
 * 功能：实现任务信息获取
 */

import java.io.Serializable;
import java.util.Calendar;

public class MissionInfo implements Serializable {
    public MissionInfo(){
        jobName=" ";
        jobScene=" ";
        jobCreateTime=Calendar.getInstance();
        jobStartTime=Calendar.getInstance();
        jobEndTime=Calendar.getInstance();
        jobType=1;
        jobDuration=0;
        jobAlreadyTime=0;
    }
    public MissionInfo(String jn,String js,Calendar jct,Calendar jst,Calendar jet,int jat,int jt,int jd){
        jobName=jn;
        jobScene=js;
        jobCreateTime=jct;
        jobStartTime=jst;
        jobEndTime=jet;
        jobAlreadyTime=jat;
        jobType=jt;
        jobDuration=jd;
    }
    public String jobName,jobScene;
    public Calendar jobCreateTime,jobStartTime,jobEndTime;
    public int jobType,jobDuration,jobAlreadyTime;
}

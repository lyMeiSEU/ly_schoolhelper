package com.example.test;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;


public class IgnitionAlgorithm {

    //系统辅助
    static Scanner s = new Scanner(System.in); //输入用
    private SQLiteHelper sql;
    //运算辅助
    int[] sixteenCounts = new int[16]; //十六时表
    boolean[] sixteenBoolean = new boolean[16]; //十六时使用表
    Calendar lastDate;//上一个日期，用于判断日期变更


    //总记录
    int totalTime; //累积时长
    int daliyTime; //当日时长(开始任务时间为当日)
    int doingNumber;//返回谁正在运算 ,-1为无任务正在进行
    int recordNumber;//记录编号

    //Job类
    final int JOB_SIZE = 8; //任务数量上限
    //int number; //当前任务数
    int[] leader = new int[JOB_SIZE]; //任务序号
    String[] jobName = new String[JOB_SIZE];//任务名称
    String[] jobType = new String[JOB_SIZE];//任务类型
    String[] jobScene = new String[JOB_SIZE];
    Calendar[] oneUserCreateTime = new Calendar[JOB_SIZE];//任务创建时间
    Calendar[] oneUserStartTime = new Calendar[JOB_SIZE];//任务开始时间
    Calendar[] oneUserEndTime = new Calendar[JOB_SIZE];//任务结束时间
    int[] oneUserSuspendDuration = new int[JOB_SIZE];//任务暂停时长/min
    int[] oneUserSetDuration = new int[JOB_SIZE];//任务设定时长/min
    int[] oneUserActualDuration = new int[JOB_SIZE];//任务实际时长/min
    int oneUserCircularity;//充实度
    int oneUserConcentration;//专注度
    //Igition类
    double oneUserIgnition;//当前燃度
    double oneUserSilence;//当前默度
    double oneUserToIgnition;//目标燃度


    //初始化算法
    public IgnitionAlgorithm(SQLiteHelper sqLiteHelper) {
        sql = sqLiteHelper;
        //辅助初始化
        for (int i = 0; i < 16; i++) {
            sixteenCounts[i] = 0;
            sixteenBoolean[i] = false;
        }
        lastDate = Calendar.getInstance();
        totalTime = 0;
        daliyTime = 0;
        doingNumber = -1;
        recordNumber = 0;
        // number = 0;

        //任务初始化
        for (int i = 0; i < JOB_SIZE; i++) {
            jobName[i] = null;
            jobType[i] = "";
            jobScene[i] = "";
            leader[i] = -1;
            oneUserCreateTime[i] = null;
            oneUserStartTime[i] = null;
            oneUserEndTime[i] = null;
            oneUserSetDuration[i] = 0;
            oneUserActualDuration[i] = 0;
            oneUserSuspendDuration[i] = 0;
        }
        //专注度充实度初始化
        oneUserCircularity = 0;
        oneUserConcentration = 0;

        //燃度初始化
        oneUserToIgnition = 0;
        oneUserIgnition = 0;
        oneUserSilence = 0;
    }

    public IgnitionAlgorithm(SQLiteHelper sqLiteHelper,double slience,double ignition) {
        sql = sqLiteHelper;
        //辅助初始化
        for (int i = 0; i < 16; i++) {
            sixteenCounts[i] = 0;
            sixteenBoolean[i] = false;
        }
        lastDate = Calendar.getInstance();
        totalTime = 0;
        daliyTime = 0;
        doingNumber = -1;
        recordNumber = 0;
        // number = 0;

        //任务初始化
        for (int i = 0; i < JOB_SIZE; i++) {
            jobName[i] = null;
            jobType[i] = "";
            jobScene[i] = "";
            leader[i] = -1;
            oneUserCreateTime[i] = null;
            oneUserStartTime[i] = null;
            oneUserEndTime[i] = null;
            oneUserSetDuration[i] = 0;
            oneUserActualDuration[i] = 0;
            oneUserSuspendDuration[i] = 0;
        }
        //专注度充实度初始化
        oneUserCircularity = 0;
        oneUserConcentration = 0;

        //燃度初始化
        oneUserToIgnition = ignition;
        oneUserIgnition = ignition;
        oneUserSilence = slience;
    }
    /*
+    JobCreate(String name, Calendar createTime, int setTime)
    概述：
        主要函数之一，用于新增一项任务并完成任务的一般属性(任务名，创建时间和设定时长)
    逻辑：
        首先搜索是否还有空位放置任务
            如果没有则报错返回
            如果有则创建任务，初始化任务属性，返回
     */
    public boolean JobCreate(String name, Calendar createTime, int setTime) {

        for (int i = 0; i < JOB_SIZE; i++) {
            if (jobName[i] == null) {
                jobName[i] = name;
                //jobScene[i] = scene;
                //jobType[i] = type;
                oneUserCreateTime[i] = createTime;
                oneUserSetDuration[i] = setTime;
                for (int j = 0; j < JOB_SIZE; j++)
                    if (leader[j] == -1) {
                        leader[j] = i;
                        System.out.println("------------》 leader"+j+"="+ i);
                        break;
                    }
                return true;
            }
        }

        System.out.println("job number has already full!");
        return false;
    }

    /*
+    JobStart(int counter, Calendar startTime)
    概述：
        主要函数之一，用于开始某项任务计时，并控制最多有且之一一个任务在进行中
    逻辑：
        首先判断是否有该任务
            如果没有报错返回
            如果有，首先判断当前是否有其他任务正在进行，
                如果有则报错返回；
                如果没有则刷新日期，当前时间更新为该任务时间所在日期，任务开始时间为输入时间，且进入执行任务状态
     */
    public boolean JobStart(int number, Calendar startTime) {
        System.out.println("--------------------->Jobstart"+number+","+leader[number]);
        int counter = leader[number];
        if (counter >= 0 && counter < JOB_SIZE) {
            if (jobName[counter] == null) {
                System.out.println("没有该任务，未能开始！");
                return false;
            } else {
                if (doingNumber != -1) {
                    System.out.println("有其他任务正在进行，未能开始！");
                    return false;
                }
                Dayflash(startTime);
                System.out.println("任务开始！");
                oneUserStartTime[counter] = startTime;
                doingNumber = counter;
                return true;
            }
        } else {
            System.out.println("错误序号，未能开始！");
            return false;
        }
    }

    /*
+    JobEnd(int counter, Calendar endTime)
    概述：
        主要函数之一，用于结束某项任务，获取用户反馈，并产生新的燃度值
    逻辑：
        首先判断是否有该任务
            如果没有报错返回
            如果有，在判断是否已经开始
                如果没有有则报错返回；
                如果有则计算实际时长，判断实际时长是否达标
                    如果没有，则报错返回
                    如果达标，则询问专注度、充实度，计算新燃度，更新十六表，最后将专注度、充实度等参数清零。
         */
    public boolean JobEnd(Calendar endTime, int suspendTime, int circularity, int concentration) throws Exception {
        //当前无任务进行中
        if (doingNumber == -1) {
            System.out.println("目前没有任务正在进行，返回");
            return false;
        }
        //当前有任务进行
        int counter = doingNumber;
        oneUserSuspendDuration[counter] = suspendTime;
        //求任务时长
        oneUserEndTime[counter] = endTime;
        oneUserActualDuration[counter] = (int) ((oneUserEndTime[counter].getTimeInMillis() - oneUserStartTime[counter].getTimeInMillis())) / (1000 * 60) + 1 - oneUserSuspendDuration[counter];
        //如果任务时长不足
        System.out.println(oneUserActualDuration[counter] + " vs " + oneUserSetDuration[counter]);
        if (oneUserActualDuration[counter] < oneUserSetDuration[counter]) {
            System.out.println("任务未完成！");
            return false;
        }
        //计入专注度和充实度
//        while (oneUserCircularity == 0) {
//            System.out.println("任务结束，请输入充实度情况：1.毫无头绪 2.小有所成 3.感到充实");
//            oneUserCircularity = s.nextInt();
//            if (oneUserCircularity != 1 && oneUserCircularity != 2 && oneUserCircularity != 3)
//                oneUserCircularity = 0;
//        }
//
//        while (oneUserConcentration == 0) {
//            System.out.println("任务结束，请输入专注度情况：1.持续走神 2.偶尔分心 3.坚持专注");
//            oneUserConcentration = s.nextInt();
//            if (oneUserConcentration != 1 && oneUserConcentration != 2 && oneUserConcentration != 3)
//                oneUserConcentration = 0;
//        }
        oneUserConcentration = concentration;
        oneUserCircularity = circularity;

        totalTime += oneUserActualDuration[counter];
        int temp = daliyTime + oneUserActualDuration[counter];
        //算燃点
        double ignition = 0.0;
        for (int i = 0; i < 16; i++) {
            if (60 < temp) {
                ignition += (10 - ((int) i / 4 + 1) * 2) * Math.pow(1.01, sixteenCounts[i]) * Math.pow(oneUserCircularity + oneUserConcentration, 2) / 40000;
                temp -= 60;
            } else if (0 < temp && temp <= 60) {
                ignition += (10 - ((int) i / 4 + 1) * 2) * Math.pow(1.01, sixteenCounts[i]) * temp / 60 * Math.pow(oneUserCircularity + oneUserConcentration, 2) / 40000;
                temp = 0;
            } else if (temp == 0) {
                break;
            }
        }
        oneUserToIgnition = ignition;
        //改十六时表
        daliyTime = daliyTime + oneUserActualDuration[counter];
        Simulation(lastDate, endTime);
        SendMessage(counter);
        oneUserCircularity = 0;
        oneUserConcentration = 0;
        doingNumber = -1;
        oneUserSuspendDuration[counter] = 0;
        return true;

    }


    /*
+     JobDelete(int counter)
   概述：
       主要函数之一，用于删除不用的任务条目（提供除名实现）
   函数逻辑：
       如果有该任务则删除，没有则报错
    */


    public void JobDelete(int number) {
        int counter = leader[number];
        leader[number] = -1;
        while (leader[++number] != -1) {
            int temp = leader[number];
            leader[number] = leader[number - 1];
            leader[number - 1] = temp;
        }


        if (counter >= 0 && counter < JOB_SIZE) {
            jobName[counter] = null;
        } else {
            System.out.println("错误序号，未能删除！");
        }
    }

    /*
+     GetCurrentIgnition()
+     GetCurrentSilence()
+     GetToIgnition()
    概述：
        返回当前燃度、默度和目标燃度，用于打印
    函数逻辑：
        直接打印
     */
    public double GetCurrentIgnition() {
        return oneUserIgnition;
    }

    public double GetCurrentSilence() {
        return oneUserSilence;
    }

    public double GetToIgnition() {
        return oneUserToIgnition;
    }

    public void SendMessage(int counter) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd,HH:mm:ss");
        System.out.print("====》 ");
        System.out.print(" [ 任务序号 : " + counter + " ],");
        System.out.print(" [ 任务名称 : " + jobName[counter] + " ],");
        System.out.print(" [ 任务类型 : " + jobType[counter] + " ],");
        System.out.print(" [ 任务场景 : " + jobScene[counter] + " ],");
        System.out.print(" [ 任务创建时间 : " + format.format(oneUserCreateTime[counter].getTime()) + " ],");
        System.out.print(" [ 任务开始时间 : " + format.format(oneUserStartTime[counter].getTime()) + " ],");
        System.out.print(" [ 任务结束时间 : " + format.format(oneUserEndTime[counter].getTime()) + " ],");
        System.out.print(" [ 任务暂停时间 : " + oneUserSuspendDuration[counter] + " ],");
        System.out.print(" [ 任务设定时间 : " + oneUserSetDuration[counter] + " ],");
        System.out.print(" [ 任务实际时长 : " + oneUserActualDuration[counter] + " ],");
        System.out.print(" [ 任务专注度 : " + oneUserConcentration + " ],");
        System.out.print(" [ 任务充实度 : " + oneUserCircularity + " ],");
        System.out.print(" [ 当前燃度 : " + oneUserIgnition + " ],");
        System.out.print(" [ 当前默度 : " + oneUserSilence + " ],");
        System.out.print(" [ 目标燃度 : " + oneUserToIgnition + " ],");
        System.out.print(" [ 今日时长 : " + daliyTime + " ],");
        System.out.print(" [ 累积时长 : " + totalTime + " ],");
        System.out.print(" [ 当前十六时表 : ");
        for (int i = 0; i < 16; i++) {
            System.out.print(sixteenCounts[i] + " , ");
        }
        System.out.print(" ]");
        sql.insertRecord(++recordNumber,jobName[counter].toString(),jobType[counter].toString(),jobScene[counter].toString(),
                oneUserCreateTime[counter].getTime().toString(),oneUserStartTime[counter].getTime().toString(),oneUserEndTime[counter].getTime().toString(),
                oneUserSuspendDuration[counter],oneUserSetDuration[counter],oneUserActualDuration[counter],
                oneUserConcentration,oneUserCircularity,oneUserIgnition,oneUserSilence,oneUserToIgnition,
                daliyTime,totalTime);//将这条记录存入本地数据库
        sql.queryAll(null);
        System.out.println();
    }

    /*
+     GetCurrentState()
    概述：
        返回当前运行状态，用于打印
    变量：
        doingState表示当前系统是否有任务在进行
    函数逻辑：
        如果正在进行则输出“正在进行”，否之输出“无进行”
     */
    public String GetCurrentState() {
        if (doingNumber != -1)
            return "正在进行";
        return "无进行";
    }

    /*
+        Dayflash(Calendar nowDate)
    概述：
        判断是否为下一（多）天，并对十六表、燃度值进行调整
    变量：
        nowDate表示当前日期
        lastDate表示上一个日期（用于辅助判断当前是否不再是同一天了）
     函数逻辑：
        首先判断是否是同一天
            如果是则直接返回，不做任何调整
            如果不是则按天数更新十六表，并重置当前燃度和目标燃度，最后将当前日期变为上一个日期（天道轮回）
     */
    public void Dayflash(Calendar nowDate) {
        if (isSameDay(lastDate, nowDate)) {
            System.out.println("同一天");
            return;
        }

        for (int j = 1; j <= MoreDay(lastDate, nowDate); j++) {
            if (j == 1) {
                for (int i = 0; i < 16; i++) {
                    if ((i + 1) * 60 <= daliyTime) {
                        if (sixteenCounts[i] < 23)
                            sixteenCounts[i] += 1;
                    } else {
                        sixteenCounts[i] /= 2;
                    }
                }
            } else {
                for (int i = 0; i < 16; i++) {
                    sixteenCounts[i] /= 2;
                }
            }
        }
        oneUserToIgnition = 0;
        oneUserIgnition = 0;
        daliyTime = 0;
        lastDate = nowDate;
        return;
    }

    /*
+    isSameDay(Calendar cal1, Calendar cal2)
    概述：
        单一功能辅助函数，用于判断两个日期是否在同一天
    变量：
        无
    逻辑：
        简单判断即可
     */
    public static boolean isSameDay(Calendar cal1, Calendar cal2) {
        if (cal1 != null && cal2 != null) {
            System.out.println(cal1.get(Calendar.YEAR) + "," + cal2.get(Calendar.YEAR) + "," + cal1.get(Calendar.MONTH) + "," + cal2.get(Calendar.MONTH) + "," + cal1.get(Calendar.DAY_OF_MONTH) + "," + cal2.get(Calendar.DAY_OF_MONTH));
            return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) && cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH) && cal1.get(Calendar.DAY_OF_MONTH) == cal2.get(Calendar.DAY_OF_MONTH);
        } else {
            throw new IllegalArgumentException("The date must not be null");
        }
    }

    /*
+    MoreDay(Calendar cal1, Calendar cal2)
    概述：
        单一功能辅助函数，用于判断两个日期相差多少天
    变量：
        timeDistance辅助判断由于不同年度导致的日期相差值
    逻辑：
        如果不是同一年，则让其变成同一年，存储年度差导致的差值，最后加上日差值
        如果是同一年则直接为日差值
     */
    public static int MoreDay(Calendar cal1, Calendar cal2) {
        int day1 = cal1.get(Calendar.DAY_OF_YEAR);
        int day2 = cal2.get(Calendar.DAY_OF_YEAR);
        int year1 = cal1.get(Calendar.YEAR);
        int year2 = cal2.get(Calendar.YEAR);

        if (year1 != year2) {  //不同一年
            int timeDistance = 0;
            for (int i = year1; i < year2; i++) {
                if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) {  //闰年
                    timeDistance += 366;
                } else {  //不是闰年
                    timeDistance += 365;
                }
            }
            return timeDistance + (day2 - day1);
        } else { //同年
            return day2 - day1;
        }
    }
    /*
+    ShowJoblist()
    概述：
        打印功能，打印当前所有的任务的序号、任务名、设定时长、创建时间
    变量：
        无
    逻辑：
        判断如果有名字则代表有任务，打印
            如果没有名字则跳过
    */
//    public void ShowJoblist(){
//        for (int i = 0;i<JOB_SIZE;i++)
//            if(jobName[i]!=null){
//                System.out.println("[ 序号： "+i+" ,任务名： "+jobName[i]+" ,设定时长："+oneUserSetDuration[i]
//                        +" ,创建时间："+oneUserCreateTime[i].getTime()+" ]");
//            }
//    }

    public void Simulation(Calendar lastdate, Calendar nowdate) {
        double v = (oneUserToIgnition - oneUserIgnition) / 60;
        int l = (int) (nowdate.getTimeInMillis() - lastdate.getTimeInMillis()) / 1000;
        int i = 0;
        int c = 0;
        int t = 0;
        while (i < l) {
            //燃度条变化
            if (i < 60) {
                oneUserIgnition += v;
            }
            //寻找对应十六时表
            for (int j = 0; j < 16; j++) {
                t += (10 - ((int) j / 4 + 1) * 2) * Math.pow(1.01, sixteenCounts[j]);
                if (oneUserSilence < t) {
                    c = j;
                    break;
                }
            }
            t = 0;
            //默度条变化
            oneUserSilence += 0.005 * (oneUserIgnition - oneUserSilence) / 100 * Math.pow(0.95, sixteenCounts[c]);
            i += 1;
            if (i % 60 == 0)
                System.out.println("$$$$$$ 模拟序列" + i + " ,当前燃度：" + oneUserIgnition + " ,当前默度：" + oneUserSilence);
        }

    }

//    public void WriteFile(){
//        try {
//            File writeName = new File("output.txt"); // 相对路径，如果没有则要建立一个新的output.txt文件
//            writeName.createNewFile(); // 创建新文件,有同名的文件的话直接覆盖
//            try (FileWriter writer = new FileWriter(writeName);
//                 BufferedWriter out = new BufferedWriter(writer))
//            {
//                out.write("我会写入文件啦1\r\n"); // \r\n即为换行
//                out.write("我会写入文件啦2\r\n"); // \r\n即为换行S
//                out.flush(); // 把缓存区内容压入文件
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

//    }

//    static public void  main(String[] args) throws Exception {
//        SaveData saveData = new SaveData();
//        IgnitionAlgorithm ig = new IgnitionAlgorithm(saveData);
//        int c = 0;
//        while(true){
//            c += 1;
//            System.out.println("=====================Action "+c+"=====================");
//            System.out.println("当前状态："+ig.GetCurrentState()+" 当前燃度："+ig.GetCurrentIgnition()+" ,目标燃度："+ig.GetToIgnition());
//
////            lpv.setPo((float)ig.GetCurrentIgnition());
////            lpv.setCurrentCount((float)ig.GetCurrentSilence());
////            lpv.postInvalidate();
//
//            System.out.println("请输入 1.创建 2.删除 3.开始 4.结束 ");
//            int choose  = s.nextInt();
//            switch(choose){
//                case 1 :
//                    System.out.println("  ----------Create Job----------");
//                    s.nextLine();
//                    System.out.println("请输入 任务名称:");
//                    String name = s.nextLine();
//                    System.out.println("请输入 设定时长:");
//                    int length = s.nextInt();
//                    ig.JobCreate(name,Calendar.getInstance(),length);
//                    System.out.println("  -----------------------------");
//                    break; //可选
//                case 2 :
//                    System.out.println("  ----------Delete Job----------");//语句
//                    s.nextLine();
//                    System.out.println("请输入 任务序号:");
//                    ig.JobDelete(s.nextInt());
//                    System.out.println("  ------------------------------");
//                    break; //可选
//                case 3 :
//                    System.out.println("  ----------Start Job----------");//语句
//                    s.nextLine();
//                    System.out.println("请输入 任务序号:");
//                    int k = s.nextInt();
//                    System.out.println("请输入 年:");
//                    int year = s.nextInt();
//                    System.out.println("请输入 月:");
//                    int month = s.nextInt();
//                    System.out.println("请输入 日:");
//                    int day = s.nextInt();
//                    System.out.println("请输入 小时:");
//                    int hour = s.nextInt();
//                    System.out.println("请输入 分钟:");
//                    int minute = s.nextInt();
//                    System.out.println("请输入 秒钟:");
//                    int second = s.nextInt();
//                    Calendar ca =Calendar.getInstance();
//                    ca.set(year,month-1,day,hour,minute,second);
//                    ig.JobStart(k,ca);
//                    System.out.println("  -----------------------------");
//                    break; //可选
//                case 4 :
//                    System.out.println("  ----------End Job----------");//语句
//                    s.nextLine();
//                    System.out.println("请输入 年:");
//                    year = s.nextInt();
//                    System.out.println("请输入 月:");
//                    month = s.nextInt();
//                    System.out.println("请输入 日:");
//                    day = s.nextInt();
//                    System.out.println("请输入 小时:");
//                    hour = s.nextInt();
//                    System.out.println("请输入 分钟:");
//                    minute = s.nextInt();
//                    System.out.println("请输入 秒钟:");
//                    second = s.nextInt();
//                    Calendar cb =Calendar.getInstance();
//                    cb.set(year,month-1,day,hour,minute,second);
//                    ig.JobEnd(cb,0,100,100);
//                    System.out.println("  ---------------------------");
//                    break; //可选
//                default : //可选
//                    //语句
//            }
//
//        }
//    }
//
//
}//类end



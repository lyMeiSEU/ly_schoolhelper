package com.example.test;
/**
 * 默燃主界面fragment适配器
 * 创建人：杜昕昱
 * 创建日期：2019.8.30
 * 功能：支持fragment翻页功能
 */
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class BurningFragmentPagerAdapter extends FragmentPagerAdapter {
    private final int PAGER_COUNT = 2;
    private ConcentrateFragment conFragment = null;
    private OtherFragment otherFragment = null;

    public BurningFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
        conFragment = new ConcentrateFragment();
        otherFragment = new OtherFragment();
    }
/**
 * 获取页数
 */
    @Override
    public int getCount() {
        return PAGER_COUNT;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        return super.instantiateItem(container, position);
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        System.out.println("position Destory" + position);
        super.destroyItem(container, position, object);
    }
//获取页面
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        switch (position) {
            case SwitchActivity.PAGE_ONE:
                fragment = conFragment;
                break;
            case SwitchActivity.PAGE_TWO:
                fragment = otherFragment;
                break;
        }
        return fragment;
    }
}


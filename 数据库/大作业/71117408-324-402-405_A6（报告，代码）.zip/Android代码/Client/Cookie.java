package com.example.test.Client;
/**
 * Author 71114715 喻泽弘
 * Date 2019.8.26
 * function 记录服务器传来的Cookie
 * */
public class Cookie {
    static String cookie=null;
}

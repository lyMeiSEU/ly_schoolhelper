package com.example.test;

/**
 * Author 71117415-喻泽弘
 * Function 购物界面
 * Date 2019.9.8
 * */

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.example.test.PagerAdapter.PageChangeIndicatorView;
import com.example.test.PagerAdapter.SerialPagerAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ExchangeActivity extends AppCompatActivity {
    //控制广告自动播放的线程信息处理器
    private Handler handler=new Handler() {
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                vpBitmap.setCurrentItem(vpBitmap.getCurrentItem() + 1, true);
            }
        }
    };
    //设置广告栏是否自动播放
    private int credit=2034;
    private boolean isAutoPlay=true;
    private PageChangeIndicatorView pciIndicator;
    private ViewPager vpBitmap;
    private LinearLayout linearLayout_1;
    private LinearLayout linearLayout_2;
    private LinearLayout linearLayout_3;
    private LinearLayout linearLayout_4;
    private int width;
    private TextView creditText;
    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(getResources().getColor(R.color.mGray));
        setContentView(R.layout.activity_exchange);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        creditText=findViewById(R.id.credit_text);
        creditText.setText("燃度值："+credit);
        initViewPager();
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        width=dm.widthPixels/2;
        linearLayout_1=findViewById(R.id.LinearLayout_1);
        linearLayout_2=findViewById(R.id.LinearLayout_2);
        linearLayout_3=findViewById(R.id.LinearLayout_3);
        linearLayout_4=findViewById(R.id.LinearLayout_4);
        addCardView();
        initIcon();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
            case R.id.action_settings:
                return true;
            default:
                break;
        }


        return super.onOptionsItemSelected(item);
    }
    //初始化ViewPager广告栏
    void initViewPager()
    {
        pciIndicator = findViewById(R.id.pci_indicator);
        vpBitmap =  findViewById(R.id.vp_Bitmap);
        vpBitmap.setAdapter(new SerialPagerAdapter(this, getBitmapList()));

        pciIndicator.setPageCount(getBitmapList().size());  //设置下标点的个数
        new Thread()
        {
            public void run()
            {
                super.run();
                while (true) {
                    try {
                        Thread.sleep(2000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if(isAutoPlay) {
                        Message message = new Message();
                        message.what = 1;
                        handler.sendMessage(message);
                    }
                }
            }
        }.start();
        //通过监听页面切换切换下标
        vpBitmap.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                pciIndicator.onPageSelectedUpdate(position % getBitmapList().size());    //切换下标
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        //给广告图片添加监听，当用户触及广告的屏幕时，取消自动轮播
        vpBitmap.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                int action=motionEvent.getAction();
                switch (action)
                {
                    case MotionEvent.ACTION_DOWN:
                        isAutoPlay=false;break;
                    case MotionEvent.ACTION_UP:
                        isAutoPlay=true;break;
                }
                return false;
            }
        });
    }
    //构建广告栏的数张图片
    public List<Bitmap> getBitmapList() {
        Bitmap bitmap01 = BitmapFactory.decodeResource(getResources(), R.drawable.advertisement_1);
        Bitmap bitmap02 = BitmapFactory.decodeResource(getResources(), R.drawable.advertisement_2);
        Bitmap bitmap03 = BitmapFactory.decodeResource(getResources(), R.drawable.advertisement_3);
        Bitmap bitmap04 = BitmapFactory.decodeResource(getResources(), R.drawable.advertisement_4);
        List<Bitmap> bitmapList = new ArrayList<>();
        bitmapList.add(bitmap01);
        bitmapList.add(bitmap02);
        bitmapList.add(bitmap03);
        bitmapList.add(bitmap04);

        return bitmapList;
    }
    //添加商品的布局
    public void addCardView()
    {
        String comString[]={"晨光优品中性笔水笔学生用考试专用笔碳素黑色水性签字笔芯0.5mm" +
                "全针管韩国小清新圆珠笔女可爱创意文具用品",
                "晨光田字本 海绵宝宝联名系列40本加厚 小学生作业本 拼音本 幼儿园田字格 生字本 作文本练字本统一标准",
                "晨光优品本味系列文具套装简约无印风按动中性笔学生用全针管笔芯0.5黑色0.35极细水性ins简约小清新签字水笔",
                "晨光孔庙祈福中性笔学生用考试专用笔0.5MM碳素黑色水性签字水笔芯心圆珠笔全针管子弹头初中生文具用品批发",
                "晨光热可擦笔3-5年级中性笔笔芯摩易檫磨魔力优握按动式可擦水笔0.38mm可爱卡通男女小学生用0.5黑晶蓝色正品"
        };
        String adString[]={"影享包邮复古风书签创意 小清新 学生用中国风diy插画可爱卡通精美纸质创意定制书签批发",
                "晨光文具中性笔0.5考试用MG-666黑/蓝水笔学生顺滑",
                "晨光笔记本子简约大学生用创意A5/16K笔记本38/40页 学生可爱记事本缝线本子",
                "晨光错题笔记本学霸笔记纠错本小学生改错记录整理本错题集高中生b5牛皮车线本初中简约本子批发大学生女",
                "晨光文具木杆铅笔HB/2H/2B六角形考试铅笔儿童三角正姿铅笔50支装AWP30411【包邮】"};
        int comResource[]={R.drawable.commodity_1,R.drawable.commodity_2,R.drawable.commodity_3,
                R.drawable.commodity_4,R.drawable.commodity_5};
        int adResource[]={R.drawable.ad_1,R.drawable.ad_2,R.drawable.ad_3,R.drawable.ad_4,R.drawable.ad_5};
        LayoutInflater flater = LayoutInflater.from(this);
        int bpHight,bpWidth;
        for(int i=0;i<5;i++) {
            View view = flater.inflate(R.layout.commodity_item, null);
            ImageView imageView = view.findViewById(R.id.comImage);
            TextView introduce=view.findViewById(R.id.comIntroduce);
            introduce.setText(comString[i]);
            TextView price=view.findViewById(R.id.comPrice);
            int r=(new Random().nextInt(5)*1000+999);
            price.setTextSize(14);
            price.setText("燃度值："+r);
            Button buy=view.findViewById(R.id.comBuy);
            buy.setOnClickListener(new ExchangeClickListener(r));
            BitmapFactory.Options options = new BitmapFactory.Options();
            BitmapFactory.decodeResource(getResources(), comResource[i], options);
            bpHight = options.outHeight;
            bpWidth = options.outWidth;
            float ratio = (float) bpWidth / (float) bpHight;
            ViewGroup.LayoutParams params = imageView.getLayoutParams();
            params.height = (int) (width / ratio);
            params.width = width;
            imageView.setLayoutParams(params);
            imageView.setBackground(getResources().getDrawable(comResource[i]));
            linearLayout_1.addView(view);
        }
        for(int i=0;i<5;i++)
        {
            View view = flater.inflate(R.layout.advertisement_item, null);
            ImageView imageView = view.findViewById(R.id.adImage);
            TextView title=view.findViewById(R.id.adTitle);
            title.setText(" 默燃好货 ");
            TextView introduce = view.findViewById(R.id.adIntroduce);
            introduce.setText(adString[i]);
            int r=(new Random().nextInt(5)*1000+999);
            Button buy=view.findViewById(R.id.adBuy);
            buy.setOnClickListener(new ExchangeClickListener(r));
            TextView price = view.findViewById(R.id.adPrice);
            price.setText("燃度值："+r);
            price.setTextSize(14);
            BitmapFactory.Options options = new BitmapFactory.Options();
            BitmapFactory.decodeResource(getResources(),adResource[i], options);
            bpHight = options.outHeight;
            bpWidth = options.outWidth;
            float ratio = (float) bpWidth / (float) bpHight;
            ViewGroup.LayoutParams params = imageView.getLayoutParams();
            params.height = (int) (width / ratio);
            params.width = width;
            imageView.setLayoutParams(params);
            imageView.setBackground(getResources().getDrawable(adResource[i]));
            linearLayout_2.addView(view);
        }
    }
    //初始化图标
    public void initIcon()
    {
        int iconWidth=width*2/7;
        int iconResource[]={R.mipmap.stationery_1,R.mipmap.stationery_2,R.mipmap.stationery_3,R.mipmap.stationery_4,
                R.mipmap.stationery_5,R.mipmap.stationery_6,R.mipmap.stationery_7,R.mipmap.stationery_8,R.mipmap.stationery_9,R.mipmap.stationery_10};
        int imageViewId[]={R.id.iconImage_1,R.id.iconImage_2,R.id.iconImage_3,R.id.iconImage_4,R.id.iconImage_5};
        int textViewId[]={R.id.iconIntroduce_1,R.id.iconIntroduce_2,R.id.iconIntroduce_3,R.id.iconIntroduce_4,R.id.iconIntroduce_5
        };
        LayoutInflater flater = LayoutInflater.from(this);
        int bpHight,bpWidth;
        View view_1 = flater.inflate(R.layout.icon_item, null);
        for(int i=0;i<5;i++)
        {
            ImageView imageView = view_1.findViewById(imageViewId[i%5]);
            imageView.setOnClickListener(new View.OnClickListener()
            {

                @Override
                public void onClick(View view) {
                    Toast toast=Toast.makeText(getApplicationContext(),"商城功能暂未支持开放",Toast.LENGTH_SHORT);
                    toast.show();
                }
            });
            TextView title=view_1.findViewById(textViewId[i%5]);
            title.setText("默");
            BitmapFactory.Options options = new BitmapFactory.Options();
            BitmapFactory.decodeResource(getResources(), iconResource[i], options);
            bpHight = options.outHeight;
            bpWidth = options.outWidth;
            float ratio = (float) bpWidth / (float) bpHight;
            ViewGroup.LayoutParams params = imageView.getLayoutParams();
            params.height = (int) (iconWidth / ratio);
            params.width = iconWidth;
            imageView.setLayoutParams(params);
            imageView.setImageResource(iconResource[i]);
        }
        linearLayout_3.addView(view_1);
        View view_2=flater.inflate(R.layout.icon_item,null);
        for(int i=5;i<10;i++)
        {
            ImageView imageView = view_2.findViewById(imageViewId[i%5]);
            TextView title=view_2.findViewById(textViewId[i%5]);
            title.setText("默");
            BitmapFactory.Options options = new BitmapFactory.Options();
            BitmapFactory.decodeResource(getResources(), iconResource[i], options);
            bpHight = options.outHeight;
            bpWidth = options.outWidth;
            float ratio = (float) bpWidth / (float) bpHight;
            ViewGroup.LayoutParams params = imageView.getLayoutParams();
            params.height = (int) (iconWidth / ratio);
            params.width = iconWidth;
            imageView.setLayoutParams(params);
            imageView.setBackground(getResources().getDrawable(iconResource[i]));
        }
        linearLayout_4.addView(view_2);
    }
    //自定义点击类 用于商品购买按钮的监听
    private class ExchangeClickListener implements View.OnClickListener
    {
        private int need=0;
        public ExchangeClickListener(int need)
        {
            this.need=need;
        }
        @Override
        public void onClick(View view) {
            if(credit<need)
            {
                Toast.makeText(getApplicationContext(),"您的燃度值不足，请加大学习力度！",Toast.LENGTH_SHORT).show();
            }else
            {
                final Dialog dialog=new Dialog(ExchangeActivity.this,R.style.Theme_AppCompat_Light_Dialog);
                View v=getLayoutInflater().inflate(R.layout.determine_dialog,null);
                dialog.setCancelable(false);
                Window window=dialog.getWindow();
                window.setGravity(Gravity.CENTER);
                //获得window窗口的属性
                TextView dText=v.findViewById(R.id.dialog_text);
                dText.setText("本次购买将花费"+need+"燃度值\n是否确认购买？");
                WindowManager.LayoutParams lp = window.getAttributes();


                //设置窗口高度为包裹内容
                lp.width=WindowManager.LayoutParams.WRAP_CONTENT;
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

                //将设置好的属性set回去

                window.setAttributes(lp);
                dialog.setContentView(v);
                dialog.show();
                Button cancel=v.findViewById(R.id.cancelButton);
                Button confirm=v.findViewById(R.id.confirmButton);
                cancel.setOnClickListener(new View.OnClickListener()
                {

                    @Override
                    public void onClick(View view) {
                        Toast.makeText(ExchangeActivity.this,"取消购买",Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                });
                confirm.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        Toast.makeText(getApplicationContext(),"购买成功",Toast.LENGTH_SHORT).show();
                        credit-=need;
                        System.out.println(credit);
                        dialog.dismiss();
                        creditText.setText("燃度值："+credit);
                    }
                });
            }
        }
    }
}


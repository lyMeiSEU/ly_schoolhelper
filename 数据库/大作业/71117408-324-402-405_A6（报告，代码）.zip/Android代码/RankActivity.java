package com.example.test;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.test.Client.ServerClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;

public class RankActivity extends AppCompatActivity {
    private RadioButton rankTime, rankBurn;
    private TextView[] rankNum, rankInfo;
    private String[] rankNumWord, rankInfoWord;
    private LinearLayout[] rankButton;
    private LinearLayout rankList;
    private int rankTotalNum;
    private String username;
    private int userRankNum;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            JSONArray rank = new JSONArray();
            try {
                rank = new JSONArray(msg.obj.toString());
                System.out.println("========================" + rank.toString());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            rankTotalNum = rank.length() - 1;
            System.out.println("==============RankNum=============" + rankTotalNum);
            init();


            try {
                JSONObject jsonNum = rank.getJSONObject(0);
                userRankNum = jsonNum.getInt("num");
                System.out.println("-----------------userRankNum---------------/-" + userRankNum);
                for (int i = 1; i < rankTotalNum+1; i++) {
                    JSONObject jsonObject = rank.getJSONObject(i);
                    rankNumWord[i - 1] = jsonObject.getString("userRank");
                    rankInfoWord[i - 1] = jsonObject.getString("userAllTime");
                }
                setRank();
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    };
    private Handler handler1 = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            JSONArray rank = new JSONArray();
            try {
                rank = new JSONArray(msg.obj.toString());
                System.out.println("========================" + rank.toString());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                JSONObject jsonNum = rank.getJSONObject(0);
                userRankNum = jsonNum.getInt("num");
                System.out.println("-----------------userRankNum---------------/-" + userRankNum);
                for (int i = 1; i < rankTotalNum+1; i++) {
                    JSONObject jsonObject = rank.getJSONObject(i);
                    rankNumWord[i - 1] = "排名"+jsonObject.getString("userRank");
                    rankInfoWord[i - 1] = jsonObject.getString("userAllTime")+"h";
                    setRank();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rank);
        username = getIntent().getStringExtra("username");
        Toolbar toolbar = findViewById(R.id.rank_toolbar);
        setSupportActionBar(toolbar);
        initRank();
        rankTime = findViewById(R.id.time_rbtn);
        rankBurn = findViewById(R.id.burn_rbtn);
        rankTime.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                setRank();
            }
        });
        rankBurn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                setRank();
            }
        });
    }

    //初始化排名界面
    private void init() {
        rankNum = new TextView[rankTotalNum];
        rankInfo = new TextView[rankTotalNum];
        rankNumWord = new String[rankTotalNum];
        rankInfoWord = new String[rankTotalNum];
        rankButton = new LinearLayout[rankTotalNum];
        rankList = findViewById(R.id.rank_page);
        for (int i = 0; i < rankTotalNum; i++) {
            rankList.addView(addRank(i));
        }
        rankTime.setChecked(true);
    }

    //添加排名
    private View addRank(int i) {
        LayoutInflater flater = LayoutInflater.from(this);
        View view = flater.inflate(R.layout.rank_layout, null);
        rankNum[i] = view.findViewById(R.id.rank_num);
        rankInfo[i] = view.findViewById(R.id.rank_info);
        rankButton[i] = (LinearLayout) view;
        return view;
    }

    //设置排名显示
    private void setRank() {
//        System.out.println("the capacity of the vector is"+a);
        //      Toast.makeText(this,a+"",Toast.LENGTH_SHORT).show();
        for (int i = 0; i < rankTotalNum; i++) {
            if(i==userRankNum){
                rankButton[i].setBackground(getDrawable(R.drawable.myrank));
            }
            rankNum[i].setText(rankNumWord[i]);
            rankInfo[i].setText(rankInfoWord[i]);
        }
    }
//初始化排名
    private void initRank() {
        ServerClient s = null;
        JSONObject object = new JSONObject();
        try {
            object.put("method", "userAllTime");
            object.put("userAccount", username);
            System.out.println(username);
            System.out.println("-----------------object-----------------" + object.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            s = new ServerClient(object.toString(), "POST", handler);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        new Thread(s).start();
    }

    private void updateTimeRank() {
        ServerClient s = null;
        JSONObject object = new JSONObject();
        try {
            object.put("method", "userAllTime");
            object.put("userAccount", username);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            s = new ServerClient(object.toString(), "POST", handler1);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        new Thread(s).start();
    }

    private void updateBurnRank() {
        ServerClient s = null;
        JSONObject object = new JSONObject();
        try {
            object.put("method", "currentIngtion");
            object.put("userAccount", username);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            s = new ServerClient(object.toString(), "POST", handler1);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        new Thread(s).start();
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}

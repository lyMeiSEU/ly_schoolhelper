package com.example.test;

/**
 * Author 71117415-喻泽弘
 * Function 报表功能的实现以及展示
 * Date 2019.9.2
 * */
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableString;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.example.test.Client.ServerClient;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.MPPointF;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class ChartActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener,
        OnChartValueSelectedListener {
    //定义xml中的cardView
    CardView mcv1;
    CardView mcv2;
    CardView mcv3;
    CardView mcv4;
    CardView mcv5;

    private Dialog mDialogChart1= null;
    private Dialog mDialogPieChart= null;
    private String username;
    private PieChart mPieChart;
    private float totalTime,burning,averageTime;
    PieChart chart;
    private LineChart mLineChart;
    private SeekBar seekBarX,seekBarY;
    private TextView tvX,tvY;
    private Typeface tfRegular;
    private Typeface tfLight;
    private List chartData;
    private float userIngtion,userAllTime,userAverageTime;
    private double dayTime[];
    private LinearLayout linearLayout;
    private TextView total;
    private TextView average;
    //初始化折线图的数据
    private List<Entry> entries=new ArrayList<>();;
    //从服务器中获取报表需要使用的信息
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);

            try {
                JSONObject jsonObject=new JSONObject(msg.obj.toString());
                System.out.println("----------------------------------"+jsonObject);
                DecimalFormat df = new DecimalFormat("#.00");
                userAllTime=Float.valueOf(df.format(Float.valueOf(jsonObject.get("userAllTime").toString())));
                userAverageTime=Float.valueOf(df.format(Float.valueOf(jsonObject.get("userAverageTime").toString())));
                total.setText(""+userAllTime+"h");
                average.setText(""+userAverageTime+"h");
                dayTime[0]=jsonObject.getDouble("0");
                dayTime[1]=jsonObject.getDouble("1");
                dayTime[2]=jsonObject.getDouble("2");
                dayTime[3]=jsonObject.getDouble("3");
                dayTime[4]=jsonObject.getDouble("4");
                dayTime[5]=jsonObject.getDouble("5");
                dayTime[6]=jsonObject.getDouble("6");
                for(int i=0;i<7;i++)
                {
                    float x=Float.valueOf(df.format(jsonObject.getDouble(Integer.toString(i))));
                    entries.add(new Entry(i,x));
                    System.out.println(entries.get(i));
                }
//                userIngtion=Float.valueOf(jsonObject.get("userIngtion").toString());
//                String string=jsonObject.getString("dayTime");
//                JSONArray timeList=new JSONArray(jsonObject.getJSONArray("dayTime"));

//                String[] strings = string.split(" ");
//                System.out.println("((((((((((((((((((("+strings);
//                for(int i=0;i<7;i++){
//                    dayTime[i]=Float.valueOf(strings[i]);
//                }
                linearLayout.setVisibility(View.GONE);
                initLineChart();
                for (int i=0;i<7;i++){
                    System.out.println("++++"+dayTime[i]);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        Toolbar toolbar = findViewById(R.id.chart_toolbar);
        total=findViewById(R.id.total);
        average=findViewById(R.id.average);
        setSupportActionBar(toolbar);
        linearLayout=findViewById(R.id.progressBar);
        username=getIntent().getStringExtra("username");
        dayTime=new double[7];
        initDataSet();
        mcv1 = findViewById(R.id.cv);
        mLineChart=findViewById(R.id.linechart);
        mLineChart.setNoDataText(" ");
        mcv1.setBackground(getResources().getDrawable(R.drawable.shape_navy_border_white_bg));
        mcv2 = findViewById(R.id.cv2);
        mcv2.setBackground(getResources().getDrawable(R.drawable.shape_red_border_white_bg));
        mcv3 = findViewById(R.id.cv3);
        mcv3.setBackground(getResources().getDrawable(R.drawable.shape_green_border_white_bg));
        mcv4 = findViewById(R.id.cv4);
        mcv4.setBackground(getResources().getDrawable(R.drawable.shape_dmagenta_border_white_bg));
        mcv5 = findViewById(R.id.cv5);
        mcv5.setBackground(getResources().getDrawable(R.drawable.shape_gold_border_white_bg));


        mcv4.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                initDialogLineChart();
                return true;
            }
        });


        initPieChart();

        mcv5.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                initDialogPieChart();
                return true;
            }
        });


    }
    //初始化折线图需要的数据
    private void initDataSet(){
        JSONObject jsonObject=null;
        jsonObject=new JSONObject();
        try {
            jsonObject.put("method","userReportForm");
            jsonObject.put("userAccount",username);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ServerClient s=null;
        try {
            s=new ServerClient(jsonObject.toString(),"POST",handler);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        new Thread(s).start();
    }
    //菜单项被选中
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    //初始化折线图
    public void initLineChart()
    {
        mLineChart.setNoDataText("暂无数据");
        //List<Entry> entries=new ArrayList<>();
        List<String> list=new ArrayList<>();
        String simpleDataFormat="MM月dd日";
        SimpleDateFormat sdf=new SimpleDateFormat(simpleDataFormat);
        Calendar c=Calendar.getInstance();
        c.add(Calendar.DATE,-7);
        Date date=c.getTime();
        for(int i=0;i<7;i++)
        {
            //entries.add(new Entry(i, new Random().nextInt(12)));
            list.add(sdf.format(date));
            c.add(Calendar.DATE,+1);
            date=c.getTime();
        }
        mLineChart.getDescription().setText("过去七天学习时间");
        XAxis xAxis=mLineChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(list));
        //设置x轴文本的颜色
        xAxis.setTextColor(Color.parseColor("#333333"));
        xAxis.setTextSize(11f);//设置文本的大小
        xAxis.setAxisMinimum(0f);
        xAxis.setLabelCount(3);
        xAxis.setDrawAxisLine(true);//是否绘制轴线
        xAxis.setDrawGridLines(false);//是否绘制x轴上每个点的线
        xAxis.setDrawLabels(true);//绘制标签 指x轴上的对应数值
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);//设置x轴的显示位置
        xAxis.setGranularity(1f);//禁止放大后x轴标签重绘
        //设置样式
        //设置图表右边的y轴的禁用
        mLineChart.getAxisRight().setEnabled(false);
        //不画y轴上对应每个点的线
        mLineChart.getAxisLeft().setDrawGridLines(false);
        LineDataSet dataSet=new LineDataSet(entries,"Label");
        //设置线条颜色
        dataSet.setColor(Color.parseColor("#ff0000"));
        //设置圆点颜色
        dataSet.setCircleColor(Color.parseColor("#FF8247"));


        //设置线条宽度
        dataSet.setLineWidth(2f);
        //设置点表示文本的大小
        dataSet.setValueTextSize(10f);
        //chart设置数据
        LineData lineData=new LineData(dataSet);
        mLineChart.setData(lineData);


        //不绘制线条上的文字
        lineData.setDrawValues(false);
        DetailsMarkerView detailsMarkerView=new DetailsMarkerView(this,R.layout.detail_marker_view);
        detailsMarkerView.setChartView(mLineChart);

        detailsMarkerView.setClickable(false);

        mLineChart.setMarker(detailsMarkerView);
        mLineChart.invalidate();//refresh
        //添加图表坐标监听 判断markView是否回收
        mLineChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                //查看覆盖物是否被回收
                if (mLineChart.isDrawMarkersEnabled()) {
                    //重新绑定覆盖物
                    //并且手动高亮覆盖物
                    mLineChart.highlightValue(h);
                }

            }

            @Override
            public void onNothingSelected() {

            }
        });

        mLineChart.setTouchEnabled(false);
        mLineChart.setDragEnabled(false);
        mLineChart.setScaleEnabled(false);
    }
    //初始化对话框中的折线图
    public void initDialogPieChart()
    {
        ImageButton mButtonGoBack2;

        mDialogPieChart= new Dialog(this, R.style.Theme_Light_Dialog);

        View v = LayoutInflater.from(this).inflate(R.layout.mydialog_chart2, null);


        //获得dialog的window窗口

        Window window =  mDialogPieChart.getWindow();

        //设置dialog在屏幕底部

        window.setGravity(Gravity.CENTER);

        //设置dialog弹出时的动画效果，从屏幕底部向上弹出

        window.setWindowAnimations(R.style.dialogStyle);



        //获得window窗口的属性

        WindowManager.LayoutParams lp = window.getAttributes();

        //设置窗口宽度为充满全屏

        lp.width = WindowManager.LayoutParams.MATCH_PARENT;

        //设置窗口高度为包裹内容

        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        //将设置好的属性set回去

        window.setAttributes(lp);

        //将自定义布局加载到dialog上

        mDialogPieChart.setContentView(v);




        mButtonGoBack2 = v.findViewById(R.id.pieChartGoBack);

        mButtonGoBack2.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view)
            {
                mDialogPieChart.dismiss();
            }
        });

        //寻找滑动条布局
        seekBarX=v.findViewById(R.id.seekBar1);
        seekBarY=v.findViewById(R.id.seekBar2);

        tvX=v.findViewById(R.id.tvXMax);
        tvY=v.findViewById(R.id.tvYMax);

        //添加滑动条的监听
        seekBarX.setOnSeekBarChangeListener(this);
        seekBarY.setOnSeekBarChangeListener(this);

        chart=v.findViewById(R.id.pieChartDetail);
        //?
        chart.setUsePercentValues(true);
        chart.getDescription().setEnabled(false);
        chart.setExtraOffsets(5,10,5,5);

        //?
        chart.setDragDecelerationFrictionCoef(0.95f);
        //设置字体
        chart.setCenterTextTypeface(tfLight);
        chart.setCenterText(generateCenterSpannableText());
        //设置中心有空洞，并且空洞的颜色为白色
        chart.setDrawHoleEnabled(true);
        chart.setHoleColor(Color.WHITE);

        //？
        chart.setTransparentCircleColor(Color.WHITE);
        chart.setTransparentCircleAlpha(110);
        //设置空洞半径
        chart.setHoleRadius(58f);
        chart.setTransparentCircleRadius(61f);

        //画中心的文本
        chart.setDrawCenterText(true);

        chart.setRotationAngle(0);
        //开启通过触控旋转图表
        chart.setRotationEnabled(true);
        //?
        chart.setHighlightPerTapEnabled(true);

        //添加选中数据的监听
        chart.setOnChartValueSelectedListener(this);

        seekBarY.setProgress(10);
        seekBarX.setProgress(4);

        //Y轴动画?
        chart.animateY(1400, Easing.EaseInOutQuad);

        Legend l = chart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.VERTICAL);
        l.setDrawInside(false);
        l.setXEntrySpace(7f);
        l.setYEntrySpace(0f);
        l.setYOffset(0f);

        //入门标签造型
        chart.setEntryLabelColor(Color.WHITE);
        chart.setEntryLabelTypeface(tfRegular);
        chart.setEntryLabelTextSize(12f);
        mDialogPieChart.show();
    }
    //初始化对话框中的折线图
    public void initDialogLineChart() {




        ImageButton mButtonGoBack;

//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//
//
//        final View v = getLayoutInflater().inflate(R.layout.mydialog_chart1, null);
//
//        builder.setView(v);
//        builder.setCancelable(false);



        mDialogChart1= new Dialog(this, R.style.Theme_Light_Dialog);

        View v = LayoutInflater.from(this).inflate(R.layout.mydialog_chart1, null);
        LinearLayout linearLayout=v.findViewById(R.id.LinearLayout_1);

        //获得dialog的window窗口

        Window window = mDialogChart1.getWindow();

        //设置dialog在屏幕底部

        window.setGravity(Gravity.CENTER);

        //设置dialog弹出时的动画效果，从屏幕底部向上弹出

        window.setWindowAnimations(R.style.dialogStyle);



        //获得window窗口的属性

        WindowManager.LayoutParams lp = window.getAttributes();

        //设置窗口宽度为充满全屏

        lp.width = WindowManager.LayoutParams.MATCH_PARENT;

        //设置窗口高度为包裹内容

        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        //将设置好的属性set回去

        window.setAttributes(lp);

        //将自定义布局加载到dialog上

        mDialogChart1.setContentView(v);




        mButtonGoBack = v.findViewById(R.id.chartGoBack);

        mButtonGoBack.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view)
            {
                mDialogChart1.dismiss();
            }
        });

        final LineChart mLineChartDetail=v.findViewById(R.id.lineChartDetail);
       // List<Entry> entries=new ArrayList<>();
        List<String> list=new ArrayList<>();
        String simpleDataFormat="MM月dd日";
        SimpleDateFormat sdf=new SimpleDateFormat(simpleDataFormat);
        Calendar c=Calendar.getInstance();
        c.add(Calendar.DATE,-7);
        Date date=c.getTime();
        for(int i=0;i<7;i++)
        {
            //int time=new Random().nextInt(12);
           // entries.add(new Entry(i,time));
            list.add(sdf.format(date));
            View v_1 = LayoutInflater.from(this).inflate(R.layout.chart_showview, null);
            TextView textView_1=v_1.findViewById(R.id.progress_textView);
            textView_1.setText(list.get(i));
            ProgressBar progressBar=v_1.findViewById(R.id.progress_chart);
            progressBar.setProgress((int)entries.get(i).getY());

            progressBar.setMax(16);
            TextView textView_2=v_1.findViewById(R.id.hour);
            textView_2.setText(entries.get(i).getY()+"h");
            linearLayout.addView(v_1);
            c.add(Calendar.DATE,+1);
            date=c.getTime();
        }
        mLineChartDetail.getDescription().setText("过去七天学习时间");
        XAxis xAxis=mLineChartDetail.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(list));
        //设置x轴文本的颜色
        xAxis.setTextColor(Color.parseColor("#333333"));
        xAxis.setTextSize(11f);//设置文本的大小
        xAxis.setAxisMinimum(0f);
        //设置x轴标签个数
        xAxis.setLabelCount(3);
        xAxis.setDrawAxisLine(true);//是否绘制轴线
        xAxis.setDrawGridLines(false);//是否绘制x轴上每个点的线
        xAxis.setDrawLabels(true);//绘制标签 指x轴上的对应数值
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);//设置x轴的显示位置
        xAxis.setGranularity(1f);//禁止放大后x轴标签重绘
        //设置样式
        //设置图表右边的y轴的禁用
        mLineChartDetail.getAxisRight().setEnabled(false);
        //不画y轴上对应每个点的线
        mLineChartDetail.getAxisLeft().setDrawGridLines(false);
        LineDataSet dataSet=new LineDataSet(entries,"学习时长");
        //设置线条颜色
        dataSet.setColor(Color.parseColor("#ff0000"));
        //设置圆点颜色
        dataSet.setCircleColor(Color.parseColor("#FF8247"));


        //设置线条宽度
        dataSet.setLineWidth(2f);
        //设置点表示文本的大小
        dataSet.setValueTextSize(10f);
        //chart设置数据
        LineData lineData=new LineData(dataSet);
        mLineChartDetail.setData(lineData);


        //不绘制线条上的文字
        lineData.setDrawValues(false);
        DetailsMarkerView detailsMarkerView=new DetailsMarkerView(this,R.layout.detail_marker_view);
        detailsMarkerView.setChartView(mLineChartDetail);

        detailsMarkerView.setClickable(false);

        mLineChartDetail.setMarker(detailsMarkerView);
        mLineChartDetail.invalidate();//refresh
        //添加图表坐标监听 判断markView是否回收
        mLineChartDetail.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                //查看覆盖物是否被回收
                if (mLineChartDetail.isDrawMarkersEnabled()) {
                    //重新绑定覆盖物
                    //并且手动高亮覆盖物
                    mLineChartDetail.highlightValue(h);
                }

            }

            @Override
            public void onNothingSelected() {

            }
        });


        mDialogChart1.show();


    }
    //初始化饼图
    private void initPieChart()
    {
        mPieChart =findViewById(R.id.piechart);
        //?
        mPieChart.setUsePercentValues(true);
        mPieChart.getDescription().setEnabled(false);
        mPieChart.setExtraOffsets(5,10,5,5);

        //?
        mPieChart.setDragDecelerationFrictionCoef(0.95f);
        //设置字体
        mPieChart.setCenterTextTypeface(tfLight);
        // mPieChart.setCenterText(generateCenterSpannableText());
        //设置中心有空洞，并且空洞的颜色为白色
        mPieChart.setDrawHoleEnabled(true);
        mPieChart.setHoleColor(Color.WHITE);

        //？
        mPieChart.setTransparentCircleColor(Color.WHITE);
        mPieChart.setTransparentCircleAlpha(110);
        //设置空洞半径
        mPieChart.setHoleRadius(58f);
        mPieChart.setTransparentCircleRadius(61f);

        //画中心的文本
        mPieChart.setDrawCenterText(true);

/*        mPieChart.setRotationAngle(0);
        //开启通过触控旋转图表
        mPieChart.setRotationEnabled(true);
        //?
        mPieChart.setHighlightPerTapEnabled(true);*/

        mPieChart.setTouchEnabled(false);


        //Y轴动画?
        mPieChart.animateY(1400, Easing.EaseInOutQuad);

        Legend l = mPieChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.VERTICAL);
        l.setDrawInside(false);
        l.setXEntrySpace(7f);
        l.setYEntrySpace(0f);
        l.setYOffset(0f);

        //入门标签造型
        mPieChart.setEntryLabelColor(Color.WHITE);
        mPieChart.setEntryLabelTypeface(tfRegular);
        mPieChart.setEntryLabelTextSize(12f);
        setData(4,10,mPieChart);
    }
    private void setData(int count,float range,PieChart pieChart)
    {
        ArrayList<PieEntry> entries = new ArrayList<>();

        // NOTE: The order of the entries when being added to the entries array determines their position around the center of
        // the mPieChart.
        for (int i = 0; i < count ; i++) {
            entries.add(new PieEntry((float) ((Math.random() * range) + range / 5),
                    MyLabel.parties[i % MyLabel.parties.length]));
        }

        PieDataSet dataSet = new PieDataSet(entries, "Election Results");

        dataSet.setDrawIcons(false);

        dataSet.setSliceSpace(3f);
        dataSet.setIconsOffset(new MPPointF(0, 40));
        dataSet.setSelectionShift(5f);

        // add a lot of colors

        ArrayList<Integer> colors = new ArrayList<>();

        for (int c : ColorTemplate.VORDIPLOM_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.JOYFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.COLORFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.LIBERTY_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.PASTEL_COLORS)
            colors.add(c);

        colors.add(ColorTemplate.getHoloBlue());

        dataSet.setColors(colors);
        //dataSet.setSelectionShift(0f);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter(mPieChart));
        data.setValueTextSize(11f);
        data.setValueTextColor(Color.WHITE);
        data.setValueTypeface(tfLight);
        pieChart.setData(data);

        // undo all highlights
        pieChart.highlightValues(null);

        pieChart.invalidate();
    }
    //定义切换详细图表dialog
    private SpannableString generateCenterSpannableText() {

        SpannableString s = new SpannableString("PieChart");
        return s;
    }
    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        tvX.setText(String.valueOf(seekBarX.getProgress()));
        tvY.setText(String.valueOf(seekBarY.getProgress()));

        setData(seekBarX.getProgress(), seekBarY.getProgress(),chart);
    }
    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {

    }

    @Override
    public void onNothingSelected() {

    }
}

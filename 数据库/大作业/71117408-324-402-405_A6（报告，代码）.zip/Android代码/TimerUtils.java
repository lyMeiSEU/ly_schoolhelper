package com.example.test;


/**
 * @author 杨宇
 * @function 将秒数转换为**：**：**时间字符串
 * 设置多个情况判断
 * @date 2019.9.10
 * @param
 * @return
 */
class TimerUtils {

    public static String getTime(int second) {

        if (second < 10) {//小于十秒定义个位，以下皆考虑各种情况

            return "00:0" + second;

        }

        if (second < 60) {

            return "00:" + second;

        }

        if (second < 3600) {

            int minute = second / 60;

            second = second - minute * 60;

            if (minute < 10) {

                if (second < 10) {

                    return "0" + minute + ":0" + second;

                }

                return "0" + minute + ":" + second;

            }

            if (second < 10) {

                return minute + ":0" + second;

            }

            return minute + ":" + second;

        }

        int hour = second / 3600;

        int minute = (second - hour * 3600) / 60;

        second = second - hour * 3600 - minute * 60;

        if (hour < 10) {

            if (minute < 10) {

                if (second < 10) {

                    return "0" + hour + ":0" + minute + ":0" + second;

                }

                return "0" + hour + ":0" + minute + ":" + second;

            }

            if (second < 10) {

                return "0" + hour + ":" + minute + ":0" + second;

            }

            return "0" + hour + ":" + minute + ":" + second;

        }

        if (minute < 10) {

            if (second < 10) {

                return hour + ":0" + minute + ":0" + second;

            }

            return hour + ":0" + minute + ":" + second;

        }

        if (second < 10) {

            return hour + ":" + minute + ":0" + second;

        }

        return hour + ":" +  minute + ":" + second;

    }



}

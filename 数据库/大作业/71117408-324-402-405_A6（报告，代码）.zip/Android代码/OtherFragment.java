/**
其他界面活动类
创建日期：2019.8.28
创建人：杜昕昱
功能：其他界面和任务界面都放置在swithactivity活动的viewpagee中，通过滑动页面进行切换。用户操作包括查看距离上次专注时间、个人信息入口、数据报表入口
      排行榜入口、购物商城的入口、社区入口。
 */
package com.example.test;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.test.Client.ServerClient;
import com.example.test.CustomerModel.CustomerModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class OtherFragment extends Fragment implements View.OnClickListener {
    private RelativeLayout info, rank, chart, shop, social;

    Timer timer = null;//距离上次专注的时间
    private boolean v = false;
    private String username;
    private TimerTask task = null;
    private String userTime = null;
    private TextView freeTimer;
    private int freeTime;
    //handler处理服务器传回来的上次专注时间
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            userTime = msg.obj.toString();
            System.out.println("-----------------msg----------------" + msg.obj.toString());
            System.out.println("+++++++++++++if++++++++++++" + (userTime.equals("NULL")));
            if (userTime.equals("NULL")) {
                freeTime = 0;
            } else {
                Calendar last = strToCalendar(userTime);
                freeTime = (int) (Calendar.getInstance().getTime().getTime() - last.getTime().getTime()) / 1000;
            }
            System.out.println("=============================freetime------------------------:" + freeTime);
        }
    };

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        username = getActivity().getIntent().getStringExtra("username");
        if (!CustomerModel.isCustomer) getLastTime();
        View view = inflater.inflate(R.layout.other_fragment, container, false);
        info = view.findViewById(R.id.person_info_entrance);
        rank = view.findViewById(R.id.rank_entrance);
        chart = view.findViewById(R.id.chart_entrance);
        shop = view.findViewById(R.id.shopping_entrance);
        social = view.findViewById(R.id.social_entrance);
        social.setOnClickListener(this);
        shop.setOnClickListener(this);
        chart.setOnClickListener(this);
        rank.setOnClickListener(this);
        info.setOnClickListener(this);
        freeTimer = view.findViewById(R.id.other_timer);
        startRecordTime();
        return view;
    }

    //向服务器获取上一次专注时间
    private void getLastTime() {
        JSONObject object = new JSONObject();
        try {
            object.put("method", "getUserTime");
            object.put("userAccount", username);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ServerClient serverClient = null;
        try {
            serverClient = new ServerClient(object.toString(), "POST", handler);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        new Thread(serverClient).start();
    }

    //设置按钮监听进入各个功能
    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.person_info_entrance:
                if (CustomerModel.isCustomer)//判断是否为游客
                {
                    Toast.makeText(getActivity(), "请登陆后查看！", Toast.LENGTH_SHORT).show();
                } else {
                    intent = new Intent(getActivity(), PersonInfoActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                }
                break;
            case R.id.rank_entrance:
                if (CustomerModel.isCustomer) {
                    Toast.makeText(getActivity(), "请登陆后查看！", Toast.LENGTH_SHORT).show();
                } else {
                    intent = new Intent(getActivity(), RankActivity.class);
                    intent.putExtra("username", username);
                    System.out.println("___________passname______________" + username);
                    startActivity(intent);
                }
                break;
            case R.id.chart_entrance:
                if (CustomerModel.isCustomer) {
                    Toast.makeText(getActivity(), "请登陆后查看！", Toast.LENGTH_SHORT).show();
                } else {
                    intent = new Intent(getActivity(), ChartActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                }
                break;
            case R.id.shopping_entrance:
                if (CustomerModel.isCustomer) {
                    Toast.makeText(getActivity(), "请登陆后查看！", Toast.LENGTH_SHORT).show();
                } else {
                    intent = new Intent(getActivity(), ExchangeActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                }
                break;
            case R.id.social_entrance:
                if (CustomerModel.isCustomer) {
                    Toast.makeText(getActivity(), "请登陆后查看！", Toast.LENGTH_SHORT).show();
                } else {
                    intent = new Intent(getActivity(), SocialActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                }
                break;
        }
    }

    //计时器线程
    private Handler mHandlerFree = new Handler() {
        public void handleMessage(Message msg) {
            freeTimer.setText(msg.obj.toString() + "");
            startRecordTime();
        }

        ;
    };

    //开始计时
    public void startRecordTime() {

        timer = new Timer();
        task = new TimerTask() {

            @Override
            public void run() {

                freeTime++;
                Message message = mHandlerFree.obtainMessage();
                String timeText = TimerUtils.getTime(freeTime);
                message.obj = timeText;
                mHandlerFree.sendMessage(message);

            }
        };
        timer.schedule(task, 1000);

    }

    public void stopRecordTime() {

        timer.cancel();
        timer = null;
        task = null;
    }

    //设置每次滑动到其他界面时计算新的专注时间，以及时更新专注信息
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!CustomerModel.isCustomer || freeTime != 0) {
            if (isVisibleToUser) {
                //TODO 可见操作
                if (v == false) {
                    v = true;
                    if (!CustomerModel.isCustomer) getLastTime();
                }

            } else {
                //TODO 不可见操作
                v = false;
            }
        }
    }
//str转calendar
    private Calendar strToCalendar(String passTime) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss:SSS");
        System.out.println("----------------------time--------" + passTime);
        Date date = null;
        try {
            date = sdf.parse(passTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar;
    }

}


import pypyodbc
import random as random
from Name import Name
path = u'Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=' + "./university.accdb"
db = pypyodbc.win_connect_mdb(path)

cur=db.cursor()
sql_MaxID="select max(ID) from student"
cur.execute(sql_MaxID)
num=int(cur.fetchall()[0][0])
with open('student.txt','w') as f:
    for i in range(num+1,5001):
        sname=Name.gen_two_words(split=' ', lowercase=False)
        if random.randint(0,1)==1:
            sex='m'
        else:
            sex='f'
        age=random.randint(15,80)
        year=random.randint(1,6)
        gpa=round(random.uniform(1,5),1)
        sql_Insert="insert into student values(%s,%s,'%s','%s',%s,%s,%s)"%(str(i),str(i),str(sname),str(sex),str(age),str(year),str(gpa))
        #print(sql_Insert)
        cur.execute(sql_Insert)
        #print('%s\t"%s"\t"%s"\t%s\t%s\t%s\n'%(str(i),str(sname),str(sex),str(age),str(year),str(gpa)))
        f.write('%s\t"%s"\t"%s"\t%s\t%s\t%s\n'%(str(i),str(sname),str(sex),str(age),str(year),str(gpa)))